//
//  RoundedButton.swift
//  Smack
//
//  Created by Tony Tresgots on 17/01/2018.
//  Copyright © 2018 Tony Tresgots. All rights reserved.
//

import UIKit

class RoundedButton: UIButton {

    var cornerRadius : CGFloat = 5.00 {
        didSet {
            self.layer.cornerRadius = cornerRadius
        }
    }
    
    func setUpView() {
        self.layer.cornerRadius = cornerRadius
    }
    
    override func awakeFromNib() {
        self.setUpView()
    }


}
