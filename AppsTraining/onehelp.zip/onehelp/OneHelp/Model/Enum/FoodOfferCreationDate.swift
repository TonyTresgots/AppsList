//
//  FoodOfferCreationDate.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import Foundation


enum FoodOfferCreationDate: String {
   
   case today = "today"
   case thisWeek = "this week"
   case thisMonth = "this month"
   
} // enum FoodOfferCreationDate: String {}
