//
//  FoodOfferDistance.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import Foundation


enum FoodOfferDistance: String {
   
   case two = "2 km"
   case five = "5 km"
   case ten = "10+ km"
   
} // enum FoodOfferDistance: String {}
