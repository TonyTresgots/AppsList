//
//  CustomUIColor.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 13/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI



enum CustomUIColor {
   
   /* * * * * * * *
    * * * * * * *
    * BACKGROUND
    */
   
   case cherryBlossomSoftPinkUI
   case treeLeafSoftMintUI
   
   /* * * * *
    * * * *
    * BLACK
    */
   
   case blackCherryUI
   
   /* * * * *
    * * * *
    * PINK
    */
   
   case cherryBlossomUI
   case cherryBlossomDarkUI
   case cherryBlossomHighLightUI
   
   /* * * *
    * * *
    * RED
    */
   
   case cherrypickerRedUI
   case cherrypickerRedLightUI
   case cherrypickerRedDarkUI
   
   /* * * * *
    * * * *
    * MINT
    */
   
   case cherryLeafMintUI
   case cherryLeafMintLightUI
   case cherryLeafMintDarkUI
   case cherryLeafMintHighLightUI
   
   /* * * * *
    * * * *
    * GREEN
    */
   
   case cherrytreeGreenUI
   case cherrytreeGreenLightUI
   case cherrytreeGreenDarkUI
   case cherrytreeGreenHighlightUI
   
   
   
    // ////////////////////
   //  COMPUTED PROPERTIES
   
   var rgbUIColorValues: UIColor {
      
      switch self {
         case .cherryBlossomSoftPinkUI : return UIColor(red : 255.00 / 255 ,
                                                        green : 240.00 / 255 ,
                                                        blue : 247.00 / 255 ,
                                                        alpha : 1)
         
         case .treeLeafSoftMintUI : return UIColor(red : 240.00 / 255 ,
                                                   green : 255.00 / 255 ,
                                                   blue : 240.00 / 255 ,
                                                   alpha : 1)
         
         case .blackCherryUI : return UIColor(red : 56.00 / 255 ,
                                              green : 47.00 / 255 ,
                                              blue : 51.00 / 255 ,
                                              alpha : 1)
         
         case .cherryBlossomUI : return UIColor(red : 255.00 / 255 ,
                                                green : 229.00 / 255 ,
                                                blue : 241.00 / 255 ,
                                                alpha : 1)
         
         case .cherryBlossomDarkUI : return UIColor(red : 247.00 / 255 ,
                                                    green : 207.00 / 255 ,
                                                    blue : 225.00 / 255 ,
                                                    alpha : 1)
         
         case .cherryBlossomHighLightUI : return UIColor(red : 247.00 / 255 ,
                                                         green : 225.00 / 255 ,
                                                         blue : 220.00 / 255 ,
                                                         alpha : 1)
         
         case .cherrypickerRedUI : return UIColor(red : 161.00 / 255 ,
                                                  green : 0.00 / 255 ,
                                                  blue : 27.00 / 255 ,
                                                  alpha : 1)
         
         case .cherrypickerRedLightUI : return UIColor(red : 186.00 / 255 ,
                                                       green : 0.00 / 255 ,
                                                       blue : 32.00 / 255 ,
                                                       alpha : 1)
         
         case .cherrypickerRedDarkUI : return UIColor(red : 137.00 / 255 ,
                                                      green : 1.00 / 255 ,
                                                      blue : 25.00 / 255 ,
                                                      alpha : 1)
         
         case .cherryLeafMintUI : return UIColor(red : 174.00 / 255 ,
                                                 green : 252.00 / 255 ,
                                                 blue : 220.00 / 255 ,
                                                 alpha : 1)
         
         case .cherryLeafMintLightUI : return UIColor(red : 224.00 / 255 ,
                                                      green : 255.00 / 255 ,
                                                      blue : 224.00 / 255 ,
                                                      alpha : 1)
         
         case .cherryLeafMintDarkUI : return UIColor(red : 183.00 / 255 ,
                                                     green : 247.00 / 255 ,
                                                     blue : 185.00 / 255 ,
                                                     alpha : 1)
         
         case .cherryLeafMintHighLightUI : return UIColor(red : 131.00 / 255 ,
                                                          green : 253.00 / 255 ,
                                                          blue : 180.00 / 255 ,
                                                          alpha : 1)
         
         case .cherrytreeGreenUI : return UIColor(red : 38.00 / 255 ,
                                                  green : 170.00 / 255 ,
                                                  blue : 10.00 / 255 ,
                                                  alpha : 1)
         
         case .cherrytreeGreenLightUI : return UIColor(red : 35.00 / 255 ,
                                                       green : 222.00 / 255 ,
                                                       blue : 116.00 / 255 ,
                                                       alpha : 1)
         
         case .cherrytreeGreenDarkUI : return UIColor(red : 48.00 / 255 ,
                                                      green : 124.00 / 255 ,
                                                      blue : 0.00 / 255 ,
                                                      alpha : 1)
         
         case .cherrytreeGreenHighlightUI : return UIColor(red : 57.00 / 255 ,
                                                           green : 222.00 / 255 ,
                                                           blue : 24.00 / 255 ,
                                                           alpha : 1)
         
         
      } // switch self {}
   } // var rgbColorValues: Color {}
   
   
   
   
   
   
} // enum CustomUIColor {}
