//
//  FoodRequestStatus.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import Foundation


enum FoodRequestStatus: String {
   
   case cancelled
   case approved
   case pending
   
} // enum RequestStatus {}
