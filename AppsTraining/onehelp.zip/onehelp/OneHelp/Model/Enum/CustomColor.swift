//
//  CustomColor.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 30/05/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


enum CustomColor {
   
   /* * * * * * * *
    * * * * * * *
    * BACKGROUND
    */
   
   case cherryBlossomSoftPink
   case treeLeafSoftMint
   
   /* * * * *
    * * * *
    * BLACK
    */
   
   case blackCherry
   
   /* * * * *
    * * * *
    * PINK
    */
   
   case cherryBlossom
   case cherryBlossomDark
   case cherryBlossomHighLight
   
   /* * * *
    * * *
    * RED
    */
   
   case cherrypickerRed
   case cherrypickerRedLight
   case cherrypickerRedDark
   
   /* * * * *
    * * * *
    * MINT
    */
   
   case cherryLeafMint
   case cherryLeafMintLight
   case cherryLeafMintDark
   case cherryLeafMintHighLight
   
   /* * * * *
    * * * *
    * GREEN
    */
   
   case cherrytreeGreen
   case cherrytreeGreenLight
   case cherrytreeGreenDark
   case cherrytreeGreenHighlight
   
   /* * * * *
    * * * *
    * MISC
    */
   
   case backgroundPink
   case backgroundDeepPink
   case backgroundGreen
   case backgroundRed
   case shadowPink
   case shadowSalmonPink
   case headerGreen
   case cherryRed
   case cherryBlossomPink
   
   case navigationbarPink
   case navigationbarMint
   
   case alertRed
   case alertGreen
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var rgbColorValues: Color {
      switch self {
         case .cherryBlossomSoftPink : return Color(red : 255.00 / 255 ,
                                                    green : 240.00 / 255 ,
                                                    blue : 247.00 / 255)
         
         case .treeLeafSoftMint : return Color(red : 240.00 / 255 ,
                                               green : 255.00 / 255 ,
                                               blue : 240.00 / 255)
         
         case .blackCherry : return Color(red : 56.00 / 255 ,
                                          green : 47.00 / 255 ,
                                          blue : 51.00 / 255)
         
         case .cherryBlossom : return Color(red : 255.00 / 255 ,
                                            green : 229.00 / 255 ,
                                            blue : 241.00 / 255)
         
         case .cherryBlossomDark : return Color(red : 247.00 / 255 ,
                                                green : 207.00 / 255 ,
                                                blue : 225.00 / 255)
         
         case .cherryBlossomHighLight : return Color(red : 247.00 / 255 ,
                                                     green : 225.00 / 255 ,
                                                     blue : 220.00 / 255)
         
         case .cherrypickerRed : return Color(red : 161.00 / 255 ,
                                              green : 0.00 / 255 ,
                                              blue : 27.00 / 255)
         
         case .cherrypickerRedLight : return Color(red : 186.00 / 255 ,
                                                   green : 0.00 / 255 ,
                                                   blue : 32.00 / 255)
         
         case .cherrypickerRedDark : return Color(red : 137.00 / 255 ,
                                                  green : 1.00 / 255 ,
                                                  blue : 25.00 / 255)
         
         case .cherryLeafMint : return Color(red : 195.00 / 255 ,
                                             green : 255.00 / 255 ,
                                             blue : 232.00 / 255)
         
         case .cherryLeafMintLight : return Color(red : 224.00 / 255 ,
                                                  green : 255.00 / 255 ,
                                                  blue : 224.00 / 255)
         
         case .cherryLeafMintDark : return Color(red : 183.00 / 255 ,
                                                 green : 247.00 / 255 ,
                                                 blue : 185.00 / 255)
         
         case .cherryLeafMintHighLight : return Color(red : 131.00 / 255 ,
                                                      green : 253.00 / 255 ,
                                                      blue : 180.00 / 255)
         
         case .cherrytreeGreen : return Color(red : 38.00 / 255 ,
                                              green : 170.00 / 255 ,
                                              blue : 10.00 / 255)
         
         case .cherrytreeGreenLight : return Color(red : 35.00 / 255 ,
                                                   green : 222.00 / 255 ,
                                                   blue : 116.00 / 255)
         
         case .cherrytreeGreenDark : return Color(red : 48.00 / 255 ,
                                                  green : 124.00 / 255 ,
                                                  blue : 0.00 / 255)
         
         case .cherrytreeGreenHighlight : return Color(red : 57.00 / 255 ,
                                                       green : 222.00 / 255 ,
                                                       blue : 24.00 / 255)
         
         /* * * * *
          * * * *
          * MISC
          */
         
         case .backgroundPink : return Color(red : 247.0/255.0 ,
                                             green : 207.0/255.0 ,
                                             blue : 225.0/255.0 )
         
         case .backgroundGreen : return Color(red : 147.0/255.0 ,
                                              green : 252.0/255.0 ,
                                              blue : 220.0/255.0 )
         
         case .backgroundRed : return Color(red : 186.0/255.0 ,
                                            green : 0.0/255.0 ,
                                            blue : 32.0/255.0 )
         
         case .backgroundDeepPink : return Color(red : 255.0/255.0 ,
                                                 green : 180.0/255.0 ,
                                                 blue : 214.0/255.0 )
         
         case .shadowPink : return Color(red : 255.0/255.0 ,
                                         green : 160.0/255.0 ,
                                         blue : 203.0/255.0 )
         
         case .shadowSalmonPink : return Color(red : 247.0/255.0 ,
                                               green : 225.0/255.0 ,
                                               blue : 220.0/255.0 )
         
         case .headerGreen : return Color(red : 48.0/255.0 ,
                                          green : 124.0/255.0 ,
                                          blue : 0.0/255.0 )
         
         case .cherryRed : return Color(red : 255.0/255.0 ,
                                        green : 160.0/255.0 ,
                                        blue : 203.0/255.0 )
         
         case .cherryBlossomPink : return Color(red : 255.0/255.0 ,
                                                green : 235.0/255.0 ,
                                                blue : 244.0/255.0 )
         
         case .navigationbarPink : return Color(red : 254.0/255.0 ,
                                                green : 213.0/255.0 ,
                                                blue : 232.0/255.0 )
         
         case .navigationbarMint : return Color(red : 195.0/255.0 ,
                                                green : 253.0/255.0 ,
                                                blue : 235.0/255.0 )
         
         case .alertRed : return Color(red : 137.0/255.0 ,
                                       green : 1.0/255.0 ,
                                       blue : 25.0/255.0)
         
         case .alertGreen : return Color(red : 38.0/255.0 ,
                                         green : 170.0/255.0 ,
                                         blue : 10.0/255.0)
         
      } // switch self {}
   } // var rgbColorValues: Color {}
   
   
   
   
} // enum CustomColor {}
