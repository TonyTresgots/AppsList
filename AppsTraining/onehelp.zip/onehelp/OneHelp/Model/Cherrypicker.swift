//
//  CP.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


class Cherrypicker: ObservableObject ,
                    Identifiable {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   let id: UUID = UUID()
   var firstName: String = ""
   var lastName: String = ""
   var pseudonym: String
   var familySize: Int = 1
   var allergies: [String] = ["gluten"]
   
   
   var foodRequests: [FoodRequest] = [
        
        FoodRequest(name : "Request 1" ,
                    status : FoodRequestStatus.cancelled ,
                    date : "26/03/2020" ,
                    statusString: "Declined" ,
                    offer : FoodOffer(nameOfferer : "Davide" ,
                                      number : 90 ,
                                      info : "test infos 9" ,
                                      pickupTime : "pickupDate 1" ,
                                      dateCreated : "02 September" ,
                                      creationDateCategory : "This  month" ,
                                      distance : "2 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 2" ,
                    status : FoodRequestStatus.approved ,
                    date : "26/03/2020" ,
                    statusString : "Declined" ,
                    offer : FoodOffer(nameOfferer : "John" ,
                                      number : 101 ,
                                      info : "test infos 90" ,
                                      pickupTime : "pickupDate 2" ,
                                      dateCreated : "02 November" ,
                                      creationDateCategory : "Today" ,
                                      distance : "5 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 3" ,
                    status : FoodRequestStatus.cancelled ,
                    date : "26/03/2020" ,
                    statusString : "Pending" ,
                    offer : FoodOffer(nameOfferer : "Bobby" ,
                                      number : 120 ,
                                      info : "test infos 900" ,
                                      pickupTime : "pickupDate 3" ,
                                      dateCreated : "29 September" ,
                                      creationDateCategory : "Today" ,
                                      distance : "5 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 4" ,
                    status : FoodRequestStatus.pending ,
                    date : "26/03/2020" ,
                    statusString : "Pending" ,
                    offer : FoodOffer(nameOfferer : "Philip" ,
                                      number : 98 ,
                                      info : "test infos 90000" ,
                                      pickupTime : "pickupDate 4" ,
                                      dateCreated : "30 January" ,
                                      creationDateCategory : "This  week" ,
                                      distance : "5 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 5",
                    status : FoodRequestStatus.pending ,
                    date : "26/03/2020",
                    statusString : "Pending" ,
                    offer : FoodOffer(nameOfferer : "Giuseppe" ,
                                      number : 78 ,
                                      info : "test infos 9000000" ,
                                      pickupTime : "pickupDate 5" ,
                                      dateCreated : "02 December" ,
                                      creationDateCategory : "This  month" ,
                                      distance : "5 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 6" ,
                    status : FoodRequestStatus.cancelled ,
                    date : "26/03/2020" ,
                    statusString : "Pending" ,
                    offer : FoodOffer(nameOfferer : "Tina" ,
                                      number : 38 ,
                                      info : "test infos 99999998" ,
                                      pickupTime : "pickupDate 6" ,
                                      dateCreated : "05 September" ,
                                      creationDateCategory : "This  week" ,
                                      distance : "2 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 7" ,
                    status : FoodRequestStatus.cancelled ,
                    date : "26/03/2020",
                    statusString : "Accepted" ,
                    offer : FoodOffer(nameOfferer : "Jeremy" ,
                                      number : 80 ,
                                      info : "test infos 1000" ,
                                      pickupTime : "pickupDate 8" ,
                                      dateCreated : "09 September" ,
                                      creationDateCategory : "This  month" ,
                                      distance: "2 km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 8" ,
                    status : FoodRequestStatus.approved ,
                    date : "26/03/2020" ,
                    statusString : "Accepted" ,
                    offer : FoodOffer(nameOfferer : "Olivier" ,
                                      number : 980 ,
                                      info : "test infos 1987" ,
                                      pickupTime : "pickupDate 19" ,
                                      dateCreated : "02 March" ,
                                      creationDateCategory : "Today" ,
                                      distance : "10+ km",
                                      shopName : "Carmina Food")) ,
        
        FoodRequest(name : "Request 9" ,
                    status : FoodRequestStatus.pending ,
                    date : "26/03/2020",
                    statusString : "Accepted" ,
                    offer : FoodOffer(nameOfferer : "Davide" ,
                                      number : 30 ,
                                      info : "test infos 78654678" ,
                                      pickupTime : "pickupDate 09" ,
                                      dateCreated : "02 June" ,
                                      creationDateCategory : "This  month" ,
                                      distance : "2 km",
                                      shopName : "Carmina Food"))
        
     ] // var foodRequests: [FoodRequest] = []
   
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
   init(pseudonym: String ,
        allergies: [String] = []) {
      
      self.pseudonym = pseudonym
      self.allergies = allergies
      
   } // init() {}
   
   
   
   
   
} // class CherryPicker {}
