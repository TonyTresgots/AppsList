//
//  RoundedCorner.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//
/* MARK: SOURCE
 * https://stackoverflow.com/questions/56760335/round-specific-corners-swiftui
 */

import SwiftUI



struct RoundedCorner: Shape  {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var radius: CGFloat = .infinity
   var corners: UIRectCorner = .allCorners
   
   
   
    // //////////////
   //  MARK: METHODS
   
   func path(in rect: CGRect)
      -> Path {
         
      let path = UIBezierPath(roundedRect : rect ,
                              byRoundingCorners : corners ,
                              cornerRadii : CGSize(width : radius ,
                                                   height : radius))
         
      return Path(path.cgPath)
         
   } // func path(in rect: CGRect) -> Path {}
   
   
   
} // struct RoundedCorner: Shape {}
