//
//  CT.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI
import MapKit


class Cherrytree: ObservableObject ,
Identifiable {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   let id: UUID = UUID()
   let firstName: String = ""
   let lastName: String = ""
   var companyName: String = ""
   var companyStreetName: String = ""
   var companyStreetNumber: Int = 33
   var companyCity: String = ""
   var companyCountry: String = ""
   var coordinates: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude : 15.3 ,
                                                                    longitude : 40.9)
   
   var foodOffers: [FoodOffer] = [
      
      FoodOffer(nameOfferer : "Davide" ,
                number : 100 ,
                info : "Info exemple" ,
                pickupTime : "Monday morning" ,
                dateCreated : "2 September" ,
                creationDateCategory : "Today" ,
                distance : "2 km",
                shopName : "Carmina Food") ,
      
      FoodOffer(nameOfferer : "Davide" ,
                number : 100 ,
                info : "Info exemple" ,
                pickupTime : "Monday morning" ,
                dateCreated : "2 September" ,
                creationDateCategory : "Today" ,
                distance : "2 km",
                shopName : "Carmina Food") ,
      
      FoodOffer(nameOfferer : "Davide" ,
                number : 100 ,
                info : "Info exemple" ,
                pickupTime : "Monday morning" ,
                dateCreated : "2 September" ,
                creationDateCategory : "Today" ,
                distance : "2 km",
                shopName : "Carmina Food") ,
      
      FoodOffer(nameOfferer : "Davide" ,
                number : 100 ,
                info : "Info exemple" ,
                pickupTime : "Monday morning" ,
                dateCreated : "2 September" ,
                creationDateCategory : "Today" ,
                distance: "2 km",
                shopName : "Carmina Food")
      
   ] // var foodOffers: [FoodOffer] = []
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var companyAddress: String {
      
      return ("\(companyName)\(companyStreetName) \(companyStreetNumber)\(companyCity)\(companyCountry)")
      
   } // var companyAddress: String {}
   
   
   
   
   
} // class CherryTree {}
