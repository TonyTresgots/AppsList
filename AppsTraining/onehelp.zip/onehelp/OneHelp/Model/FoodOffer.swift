//
//  Offer.swift
//  OneHelp
//
//  Created by Tony Tresgots on 21/05/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


class FoodOffer : ObservableObject ,
                  Identifiable {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   let id: UUID = UUID()
   
   var nameOfferer: String
   var info: String
   var pickupTime: String
   var imageName: String
   var number: Int
   var dateCreated: String
   var distance: String
   var creationDateCategory: String
   var shopName : String
    
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
    init(imageName: String = "cube.box.fill" ,
         nameOfferer: String ,
         number: Int ,
         info: String ,
         pickupTime: String ,
         dateCreated: String ,
         creationDateCategory: String ,
         distance: String,
         shopName: String) {
      
      self.imageName            = imageName
      self.number               = number
      self.info                 = info
      self.pickupTime           = pickupTime
      self.dateCreated          = dateCreated
      self.creationDateCategory = creationDateCategory
      self.distance             = distance
      self.nameOfferer          = nameOfferer
      self.shopName             = shopName
        
   } // init?{}
} // struct FoodOffer}





 // /////////////////
//  MARK: SAMPLEDATA

var foodOffersSampleData: [FoodOffer] = [
   
    FoodOffer(nameOfferer : "Bob" ,
              number : 100 ,
              info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
              pickupTime : "Monday morning" ,
              dateCreated : "2 September" ,
              creationDateCategory : "Today" ,
              distance : "2 km",
              shopName : "Carmina Food") ,
    
    FoodOffer(nameOfferer : "Alex" ,
              number : 200 ,
              info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice .", pickupTime: "Monday afternoon" ,
              dateCreated : "2 November" ,
              creationDateCategory : "Today" ,
              distance : "2 km",
              shopName : "Genova Food") ,
    
   FoodOffer(nameOfferer : "Bobby" ,
             number : 300 ,
             info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
             pickupTime : "Saturday morning" ,
             dateCreated : "10 September" ,
             creationDateCategory : "This week" ,
             distance : "2 km",
             shopName : "FoodNco") ,
   
   FoodOffer(nameOfferer : "John" ,
             number : 400 ,
             info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
             pickupTime : "Monday morning" ,
             dateCreated : "22 September" ,
             creationDateCategory : "This month" ,
             distance : "5 km",
             shopName : "EatitNow") ,
   
   FoodOffer(nameOfferer : "Davide" ,
             number : 500 ,
             info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
             pickupTime : "Monday morning" ,
             dateCreated : "29 September" ,
             creationDateCategory : "This month" ,
             distance : "10+ km",
             shopName : "FoodyLovy")
   
] // let foodOfferSampleData = []
