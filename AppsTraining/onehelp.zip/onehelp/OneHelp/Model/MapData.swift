//
//  MapData.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 02/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI
import MapKit


struct MapData : Identifiable {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var id: UUID = UUID()
   var name: String
   var coordinates: CLLocationCoordinate2D
   var address: String
   
   
   
} // struct MapData {}





 // /////////////////
//  MARK: SAMPLEDATA

let mapSampleData = [
   
   MapData(name : "Place 1" ,
           coordinates : CLLocationCoordinate2D(latitude : 15.3 , longitude : 40.9) ,
           address: "Rue des lilas") ,
   
   MapData(name : "Place 2" ,
           coordinates : CLLocationCoordinate2D(latitude : 18.3 , longitude : 40.9) ,
           address : "Rue des lilas") ,
   
   MapData(name : "Place 3" ,
           coordinates : CLLocationCoordinate2D(latitude : 12.3 , longitude : 40.9) ,
           address : "Rue des lilas") ,
   
   MapData(name : "Place 4" ,
           coordinates : CLLocationCoordinate2D(latitude : 20.3 , longitude : 40.9) ,
           address : "Rue des lilas") ,
   
   MapData(name : "Place 5" ,
           coordinates : CLLocationCoordinate2D(latitude : 80.9 , longitude : 40.9) ,
           address : "Rue des lilas")
   
] // let mapSampleData = []

