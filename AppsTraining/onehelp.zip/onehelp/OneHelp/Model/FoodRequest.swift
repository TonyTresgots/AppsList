//
//  FoodRequest.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


class FoodRequest : Identifiable ,
                    ObservableObject {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var id: UUID = UUID()
   var name: String
   var status: FoodRequestStatus
   var date: String
   var statusString: String?
   var offer: FoodOffer
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @Published var cancelledFoodRequests: [FoodRequest] = []
   @Published var approvedFoodRequests: [FoodRequest] = []
   @Published var pendingFoodRequests: [FoodRequest] = []
   
   
   
    // //////////////////////////
   //  MARK: INITIALISER METHODS
   
   init(name: String ,
        status: FoodRequestStatus ,
        date: String ,
        statusString: String ,
        offer: FoodOffer) {
      
      self.name         = name
      self.status       = status
      self.date         = date
      self.statusString = statusString
      self.offer        = offer
      
   } // init() {}
} // struct Request : Identifiable {}





 // /////////////////
//  MARK: SAMPLEDATA

var foodRequestsSampleData: [FoodRequest] = [
   
   FoodRequest(name : "Bob" ,
               status : FoodRequestStatus.cancelled ,
               date : "26/03/2020",
               statusString : "Declined" ,
               offer: FoodOffer(nameOfferer : "Davide" ,
                                number : 90 ,
                                info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                pickupTime : "pickup time" ,
                                dateCreated : "03 Sept." ,
                                creationDateCategory : "Today" ,
                                distance : "2 km",
                                shopName : "Carmina Food")) ,
   
   FoodRequest(name : "Giovanni" ,
               status : FoodRequestStatus.approved ,
               date : "26/03/2020",
               statusString : "Accepted" ,
               offer : FoodOffer(nameOfferer : "Joe" ,
                                 number : 80 ,
                                 info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "06 Sept." ,
                                 creationDateCategory : "Today" ,
                                 distance : "2 km",
                                 shopName : "FoodyLovy")) ,
   
   FoodRequest(name : "Philip" ,
               status : FoodRequestStatus.cancelled ,
               date : "26/03/2020" ,
               statusString : "Pending" ,
               offer : FoodOffer(nameOfferer : "Olivier" ,
                                 number : 40 ,
                                 info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "08 Sept." ,
                                 creationDateCategory : "Today" ,
                                 distance : "2 km",
                                 shopName : "FoodNCo")) ,
   
   FoodRequest(name : "John" ,
               status : FoodRequestStatus.pending ,
               date : "26/03/2020",
               statusString : "Accepted" ,
               offer : FoodOffer(nameOfferer : "Philip" ,
                                 number : 10, info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "12 Sept." ,
                                 creationDateCategory : "This week" ,
                                 distance : "5 km",
                                 shopName : "Genova Food")) ,
   
   FoodRequest(name : "Joe",
               status : FoodRequestStatus.pending ,
               date : "26/03/2020",
               statusString : "Accepted" ,
               offer : FoodOffer(nameOfferer : "Giuseppe" ,
                                 number : 30 ,
                                 info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "14 Sept." ,
                                 creationDateCategory : "This week" ,
                                 distance : "5 km",
                                 shopName : "EatItNow")) ,
   
   FoodRequest(name : "James" ,
               status : FoodRequestStatus.cancelled ,
               date : "26/03/2020",
               statusString : "Pending" ,
               offer : FoodOffer(nameOfferer : "Tina" ,
                                 number : 40 ,
                                 info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "19 Sept." ,
                                 creationDateCategory : "This month" ,
                                 distance : "5 km",
                                 shopName : "FooFood")) ,
   
   FoodRequest(name : "Eric" ,
               status : FoodRequestStatus.cancelled ,
               date : "26/03/2020",
               statusString : "Declined" ,
               offer : FoodOffer(nameOfferer : "Jeremy" ,
                                 number : 45 ,
                                 info : "The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice ." ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "20 Sept." ,
                                 creationDateCategory : "This month" ,
                                 distance : "10+ km",
                                 shopName : "Carmina Food")) ,
   
   FoodRequest(name : "Clint" ,
               status : FoodRequestStatus.approved ,
               date : "26/03/2020",
               statusString : "Pending" ,
               offer : FoodOffer(nameOfferer : "Jonathan" ,
                                 number : 46 ,
                                 info : "test infos 8" ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "30 Sept." ,
                                 creationDateCategory : "This month" ,
                                 distance : "10+ km",
                                 shopName : "Carmina Food")) ,
   
   FoodRequest(name : "Gerald" ,
               status : FoodRequestStatus.pending ,
               date : "26/03/2020",
               statusString : "Pending" ,
               offer : FoodOffer(nameOfferer : "Davide" ,
                                 number : 32 ,
                                 info : "test infos 9" ,
                                 pickupTime : "fffff" ,
                                 dateCreated : "02 Sept." ,
                                 creationDateCategory : "This  month" ,
                                 distance : "10+ km",
                                 shopName : "FoodyLovy"))
   
] // var foodRequestSampleData = []
