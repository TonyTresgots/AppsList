//
//  ViewExtension.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//
/* MARK: SOURCE
 * https://stackoverflow.com/questions/56760335/round-specific-corners-swiftui
 */

import SwiftUI


extension View {
   
   func cornerRadius(_ radius: CGFloat ,
                     corners: UIRectCorner)
      -> some View {
         
      clipShape( RoundedCorner(radius : radius ,
                               corners : corners) )
         
   } // func cornerRadius(_ radius: CGFloat , corners: UIRectCorner)  -> some View {}
   
   
   
   
} // extension View {}





class AppState: ObservableObject {

    func reloadDashboard() {
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.reloadDashboard()
    } // func reloadDashboard() {}


    func realoadDashboard2() {
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.reloadDashboard2()
    } // func realoadDashboard2() {}

} // class AppState: ObservableObject {}
