//
//  CherrytreeProfileIntroDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerProfileIntroDetailView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
      
      
      
   } // var body: some View {}
} // struct CherrytreeProfileIntroDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeProfileIntroDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerProfileIntroDetailView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeProfileIntroDetailView_Previews: PreviewProvider {}
