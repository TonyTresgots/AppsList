//
//  CherrypickerFoodRequestTabView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeRequestDetailView: View {
    
    // /////////////////
    //  MARK: PROPERTIES
    
    var backGroundColor: Color = CustomColor.backgroundGreen.rgbColorValues
    var textColor: Color = CustomColor.headerGreen.rgbColorValues
    
    var request : FoodRequest
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    @State private var showingAlert = false
    @State private var accepted = false

    
    // //////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var body: some View {
        
        VStack(alignment: .center) {
            ZStack {
                Circle()
                    .foregroundColor(Color.clear)
                    .overlay(
                        Circle()
                            .stroke(style : StrokeStyle(lineWidth : 9.0)))
                    .frame(width : 320 ,
                           height : 320 ,
                           alignment : .center)
                    .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                
                Group {
                    if request.offer.imageName == "" {
                        Image(systemName : "photo")
                            .font(.largeTitle)
                            .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                    } else {
                        Image(request.offer.imageName)
                            .font(.largeTitle)
                    } // if request.offer.imageName == "" {} else {}
                } // Group {}
                
            } // ZStack {}
                .padding(.top)
            
            
            VStack(alignment : .leading) {
                Text("Request number \(request.offer.number)".uppercased())
                    .fontWeight(.bold)
                    .font(.caption)
                    .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                    .padding(.vertical , 10)
                
                
                CherrypickerMicroStory(request: request)
                
                
            } // VStack(alignment : .leading) {}
                .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                .font(Font.system(size : 21.0 ,
                                  weight : .semibold))
            
            
            Spacer()
            
            
            Button(action: {
                print("The Accept Button is tapped .")
                self.accepted = true
                self.showingAlert = true
            }) {
                if self.request.statusString == "Pending" {
                    Text("Accept")
                        .font(Font.system(size : 21.0 , weight : .medium))
                        .foregroundColor(Color.white)
                        .padding(.horizontal , 90.0)
                        .padding(20)
                        .background(
                            RoundedRectangle(cornerRadius : .infinity)
                                .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues))
                        
                }
            } // Button(action: {}) {}

            Spacer()
        
        } // VStack
            .padding()
            .navigationBarTitle(Text(request.name) ,
                                displayMode : .inline)
            .navigationBarItems(trailing : Button(action : {
                print("The Reject offer button has been tapped .")
                self.accepted = false
                self.showingAlert = true
                
            }) {
                if self.request.statusString == "Pending" {
                    Image(systemName: "bin.xmark.fill")
                        .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                        .font(Font.system(size : 27 ,
                                          weight : .medium))
                }
                
            }) // .navigationBarItems(trailing:) {}
        .alert(isPresented: $showingAlert) {
            Alert(title: Text(accepted ? "Request accepted" : "Request declined"), message: Text(accepted ? "You successfully accepted this request !" : "You successfully declined this request !"), dismissButton: .default(Text("Got it!")) {
                    self.request.statusString = self.accepted ? "Accepted" : "Declined"
                    self.presentationMode.wrappedValue.dismiss()
                })
            
        }

    } // var body: some View {}
} // struct CherrypickerFoodRequestDetailView: View {}





// ///////////////
//  MARK: PREVIEWS

struct CherrypickerFoodRequestDetailView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        CherrytreeRequestDetailView(request : FoodRequest(name : "" ,
                                                          status : FoodRequestStatus.approved ,
                                                          date : "" ,
                                                          statusString : "" ,
                                                          offer : FoodOffer(nameOfferer : "" ,
                                                                            number : 0 ,
                                                                            info : "" ,
                                                                            pickupTime : "" ,
                                                                            dateCreated : "" ,
                                                                            creationDateCategory : "" ,
                                                                            distance : "",
                                                                            shopName : "Carmina Food")))
        
        
        
    } // static var previews: some View {}
} // struct CherrypickerFoodRequestTabView_Previews: PreviewProvider {}
