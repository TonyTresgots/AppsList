//
//  CherrytreeOfferDetailEditView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeOfferEditSheet: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundGreen.rgbValues
   var textColor: Color = CustomColor.headerGreen.rgbValues
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      ZStack(alignment : .topLeading) {
         Rectangle()
            .edgesIgnoringSafeArea(.all)
            .applyBackgroundGradient(accentColor : backGroundColor.opacity(0.55))
         
         Group {
            Text("Edit Food Offer")
               .font(Font.system(size: 21.0 ,
                                 weight: .semibold,
                                 design: .rounded))
               .lineSpacing(10.0)
               .foregroundColor(textColor)
         } // Group {}
            .padding()
            .padding(.top , 15)
      } // ZStack {}
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferEditDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOfferEditDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeOfferEditSheet()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeOfferEditDetailView_Previews: PreviewProvider {}
