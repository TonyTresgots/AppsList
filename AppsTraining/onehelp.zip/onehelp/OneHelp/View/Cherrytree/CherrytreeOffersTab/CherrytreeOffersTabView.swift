//
//  CherrytreeCreateFoodOffer.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeOffersTabView: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var offers: [FoodOffer] = foodOffersSampleData
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @ObservedObject var cherrypicker: Cherrypicker = Cherrypicker(pseudonym : "George Cherrypicker")
   
   @State private var isShowingCreateNewOfferSheet: Bool = false
   
   @State private var dateCreationIndex = 0
   
   @State private var dateCreation = [
      NSLocalizedString("Today" , comment : "") ,
      NSLocalizedString("This week" , comment : "") ,
      NSLocalizedString("This month" , comment : "")
   ] // @State private var status = []
    
    
     // //////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var statusPicked: [FoodOffer] {
       foodOffersSampleData.filter { $0.creationDateCategory == dateCreation[dateCreationIndex] }
    } // var statusPicked: [Request] {}
   
    
   var body: some View {
      
      NavigationView {
         List {
            Picker(selection : $dateCreationIndex ,
                   label : Text("Text")) {
                     
                     ForEach(0..<dateCreation.count) { index in
                        Text(self.dateCreation[index]).tag(index)
                     } // ForEach({ {}
                     
            } // Picker(selection) {}
               .pickerStyle(SegmentedPickerStyle())
               .padding(.bottom , 5)
            
            
            ForEach(statusPicked) { foodOffer in
               NavigationLink(destination : CherrytreeOfferDetailView(foodOffer : foodOffer)) {
                  
                  //                  CherrypickerFoodRequestNavigationLink(foodOffer: foodOffer )
                  CherrytreeCreatedFoodOfferNavigationLink(foodOffer: foodOffer)
                  
               } // NavigationLink(destination:) {}
            } // ForEach() {}
               .onDelete(perform : removeFoodOfferRows)
            
         } // List() {}
           //  .id(UUID())
            .navigationBarItems(trailing : Button(action : {
               print("The Add offer button has been tapped .")
               self.isShowingCreateNewOfferSheet.toggle()
            }) {
               Image(systemName: "plus.circle")
                  .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                  .font(Font.system(size : 27 ,
                                    weight : .medium))
            }) // .navigationBarItems(trailing:) {}
            .sheet(isPresented : $isShowingCreateNewOfferSheet) {
               CherrytreeCreateNewOfferSheet(isPresented: self.$isShowingCreateNewOfferSheet)
         } // .sheet(isPresented:) {}
            .navigationBarTitle(Text("Offers"))
      } // NavigationView {}
         .accentColor(CustomColor.cherrytreeGreen.rgbColorValues)
      
      
      
   } // var body: some View {}
    
    
    
     // //////////////
    //  MARK: METHODS
    
    func removeFoodOfferRows(at offsets: IndexSet) {
        /* Because our ForEach was created entirely from a single array ,
         * we can actually just pass that index set
         * straight to our numbers array
         * – it has a special remove(atOffsets:) method
         * that accepts an index set :
         */
        foodRequestsSampleData.remove(atOffsets : offsets)
    } // func removeRows(at offsets:) {}
    
   

    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      UITableView.appearance().separatorStyle = .none
      UITableView.appearance().backgroundColor = .clear
      UITableViewCell.appearance().backgroundColor = .clear
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues]
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = CustomUIColor.cherrytreeGreenDarkUI.rgbUIColorValues
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : CustomUIColor.cherrytreeGreenDarkUI.rgbUIColorValues] ,
                                 for : .normal)
   } // init() {}
   
   
   
} // struct CherrytreeCreateFoodOfferTabView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeCreateFoodOfferTabView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        CherrytreeOffersTabView()
        
        
        
    } // static var previews: some View {}
} // struct CherrytreeCreateFoodOfferTabView_Previews: PreviewProvider {}
