//
//  CherrytreeOfferDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeOfferDetailView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var isShowingCherrytreeOfferEditDetailView: Bool = false
   @State var foodOffer: FoodOffer
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      List {
         VStack(alignment : .center) {
            
            DetailViewImageFrame(accentColor : CustomColor.cherrytreeGreen.rgbColorValues ,
                                 iconImageColor : CustomColor.cherrytreeGreenDark.rgbColorValues ,
                                 foodOffer : foodOffer)
               .frame(width : 320 ,
                      height : 320 ,
                      alignment : .center)
               .padding(.top)

            VStack(alignment : .leading) {
                FoodOfferDescription(accentColor : CustomColor.cherrytreeGreen.rgbColorValues ,
                                     offer: foodOffer ,
                                     titleColor : CustomColor.cherrytreeGreenDark.rgbColorValues)
                  .padding(.bottom , 20)
               
               PickupTimeTable(accentColor : CustomColor.cherrytreeGreenDark.rgbColorValues)
                  .padding(.bottom , 20)
               
               CompanyAddress(accentColor : CustomColor.cherrytreeGreenDark.rgbColorValues)
            } // VStack(alignment: .leading) { {}
         } // VStack(alignment: .center) { {}
            .padding(.horizontal , 8)
      } // List {}
         .navigationBarTitle(Text("Carmina Food") ,
                             displayMode : .inline)
         .navigationBarItems(trailing : Button(action : {
            print("The Edit offer button has been tapped .")
            self.isShowingCherrytreeOfferEditDetailView.toggle()
         }) {
            Image(systemName: "square.and.pencil")
               .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
               .font(Font.system(size : 27 ,
                                 weight : .medium))
         }) // .navigationBarItems(trailing:) {}
         .sheet(isPresented : $isShowingCherrytreeOfferEditDetailView) {
            CherrytreeEditOfferSheet()
      } // .sheet(isPresented:) {}
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOfferDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeOfferDetailView(foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                      number : 100 ,
                                                      info : "Info example" ,
                                                      pickupTime : "Monday morning" ,
                                                      dateCreated : "2 September" ,
                                                      creationDateCategory : "Today" ,
                                                      distance : "2 km",
                                                      shopName : "Carmina Food"))

   } // static var previews: some View {}
} // struct CherrytreeOfferDetailView_Previews: PreviewProvider {}
