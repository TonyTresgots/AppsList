//
//  CherrytreeCreateNewOfferSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeCreateNewOfferSheet: View {
    
    // ////////////////////////
    //  MARK: PROPERTY WRAPPERS
    
    @State var isShowingCherrytreeOfferEditDetailView: Bool = false
    
    @State var foodOffer: FoodOffer = FoodOffer(nameOfferer : "Davide" ,
                                                number : 100 ,
                                                info : "Info example" ,
                                                pickupTime : "Monday morning" ,
                                                dateCreated : "2 September" ,
                                                creationDateCategory : "Today" ,
                                                distance : "2 km",
                                                shopName : "Carmina Food")
    
    @State private var numberOfPeople: Int = 2
    @State private var foodOfferDescription: String = ""
    
    @Binding var isPresented: Bool
    
    // //////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var body: some View {
        
        List {
            VStack(alignment : .center) {
                Image(systemName : "camera.fill")
                    .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                    .font(Font.system(size : 40 ,
                                      weight : .medium))
                    .padding(.vertical , 30)
                
                
                VStack(alignment : .leading) {
                    Text("Offer number 1".uppercased())
                        .fontWeight(.bold)
                        .font(.caption)
                        .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                        .padding(.vertical , 10)
                    
                    Text("Your food offer description to the food receivers : ")
                        .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                        
                        + Text("The offer includes a box for \(numberOfPeople) \(numberOfPeople == 1 ? "human" : "people") with \(foodOfferDescription)")
                    
                    Spacer()
                } // VStack {}
                    .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                    .font(Font.system(size : 21.0 ,
                                      weight : .semibold))
                    .padding()
                    .frame(width : 320.0 ,
                           height : 250.0 ,
                           alignment : .leading)
                    .background(
                        RoundedRectangle(cornerRadius : 12.0)
                            .stroke(style : StrokeStyle(lineWidth : 6.0))
                            .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues))
                    .padding(.bottom , 30)
                
                /* ENTER NUMBER OF PEOPLE :
                 */
                
                HStack {
                    Image(systemName : "person.3.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width : 55.0 ,
                               height : 21.0 ,
                               alignment: .center)
                    Text("number of people".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                    Spacer()
                    
                    Stepper("" , value: $numberOfPeople)
                } // HStack {}
                    .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                    .frame(width : 320.0)
                    .padding(.bottom , 20)
                
                
                /* ENTER FOOD OFFER DESCRIPTION :
                 */
                
                ZStack(alignment : .leading) {
                    if foodOfferDescription.isEmpty {
                        HStack {
                            Spacer()
                            Text("Your food offer description".uppercased())
                                .font(Font.system(size : 13.0 ,
                                                  weight : .light))
                            Spacer()
                        } // HStack {}
                            .foregroundColor(Color.secondary)
                    } // if foodAllergy.isEmpty {}
                    
                    TextField("" , text : $foodOfferDescription)
                        .multilineTextAlignment(.center)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                        .padding(.horizontal)
                } // ZStack {}
                    .overlay(
                        RoundedRectangle(cornerRadius : 8)
                            .stroke(Color.secondary ,
                                    lineWidth: 1))
                    .font(Font.system(size : 21.0 ,
                                      weight : .semibold))
                    .frame(width : 320.0)
                    .padding(.bottom , 20)
                
                
                Divider()
                    .background(CustomColor.blackCherry.rgbColorValues)
                
                
                VStack(alignment : .leading) {
                    PickupTimeTable(accentColor : CustomColor.cherrytreeGreenDark.rgbColorValues)
                        .padding(.vertical , 20)
                    
                    CompanyAddress(accentColor : CustomColor.cherrytreeGreenDark.rgbColorValues)
                    
                    
                        
                } // VStack(alignment: .leading) { {}
                                
                Text("Save").onTapGesture {
                    self.isPresented = false
                    
                    let createdOffer = FoodOffer(nameOfferer: "Bob", number: 30, info: "Pack of pasta", pickupTime: "", dateCreated: "17 June", creationDateCategory: "Today", distance: "2 km", shopName: "Carmina Food")
                    foodOffersSampleData.append(createdOffer)
                }
                
                .font(Font.system(size : 21.0 , weight : .medium))
                .padding(.horizontal , 90.0)
                .padding(20)
                .background(
                RoundedRectangle(cornerRadius : .infinity)
                    .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues))
                .foregroundColor(.white)
                .padding(.top, 20)
                
                
            } // VStack(alignment: .center) { {}
                .padding(.horizontal , 8)
        } // List {}

                    
                    
                    

        
        
        
    } // var body: some View {}
} // struct CherrytreeCreateNewOfferSheet: View {}
