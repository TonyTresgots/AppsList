//
//  CherrytreeCreateFoodOffer.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeCreateFoodOfferTabView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Text("Cherrytree Create Food Offer")
      
      
      
   } // var body: some View {}
} // struct CherrytreeCreateFoodOffer: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeCreateFoodOffer_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeCreateFoodOfferTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeCreateFoodOffer_Previews: PreviewProvider {}
