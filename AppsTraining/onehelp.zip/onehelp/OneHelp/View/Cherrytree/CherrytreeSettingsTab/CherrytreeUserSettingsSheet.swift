//
//  CherrytreeUserSettingsSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeUserProfileSheet: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var isShowingContactDetailsSheet: Bool = false
   @State private var isShowingDestroyAccountSheet: Bool = false
   @State private var yourFirstName: String = ""
   @State private var yourLastName: String = ""
   @State private var yourEmailAddress: String = ""
   @State private var yourMobilePhoneNumber: String = ""
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack {
         VStack(alignment : .leading , spacing: 18.0) {
            
            /* YOUR FIRST NAME :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if yourFirstName.isEmpty {
                     HStack {
                        Spacer()
                        Text("Your first name".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $yourFirstName)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 21.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.cherrytreeGreenDark.rgbColorValues)
            
            
            /* YOUR LAST NAME :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if yourLastName.isEmpty {
                     HStack {
                        Spacer()
                        Text("Your last name".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $yourLastName)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 21.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.cherrytreeGreenDark.rgbColorValues)
            
            
            /* YOUR EMAIL ADDRESS :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if yourEmailAddress.isEmpty {
                     HStack {
                        Spacer()
                        Text("Your email address".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $yourEmailAddress)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 21.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.cherrytreeGreenDark.rgbColorValues)
            
            
            /* YOUR MOBILE PHONE NUMBER :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if yourMobilePhoneNumber.isEmpty {
                     HStack {
                        Spacer()
                        Text("Your mobile phone number".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $yourMobilePhoneNumber)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 21.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.cherrytreeGreenDark.rgbColorValues)
            
         } // VStack(alignment: , spacing: ) {}
            .navigationBarTitle(Text("User Profile") , displayMode : .inline)
            .navigationBarItems(trailing : Button(action : {
               print("The Add offer button has been tapped .")
            }) {
               Image(systemName: "checkmark.circle")
                  .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                  .font(Font.system(size : 27 ,
                                    weight : .medium))
            }) // .navigationBarItems(trailing:) {}
            .padding()
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
            .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
         
         
         Spacer()
         
         /* DELETE ACCOUNT :
          */
         
         HStack {
            Spacer()
            
            Button(action : {
               self.isShowingDestroyAccountSheet.toggle()
            }) {
               Text("Delete Account")
                  .font(Font.system(size : 18.0 ,
                                    weight : .medium))
                  .underline()
                  .foregroundColor(Color.red)
                  .padding()
            } // Button(action: {}) {}
               .padding(.bottom , 30)
               .sheet(isPresented: $isShowingDestroyAccountSheet) {
                  CherrytreeDestroyAccountSheet()
            } // Button(action : {}) {}
            
            Spacer()
         } // .sheet(isPresented:) {}
         
         
         
      } // VStack {}
      
      
   } // var body: some View {}
} // struct CherrytreeUserSettingsSheet: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeUserSettingsSheet_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeUserProfileSheet()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeUserSettingsSheet_Previews: PreviewProvider {}
