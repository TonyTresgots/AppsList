//
//  CherrytreeProfileView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeSettingsTabView: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundGreen.rgbValues
   var accentColor: Color = CustomColor.headerGreen.rgbValues
   var alertColor: Color = CustomColor.alertGreen.rgbValues
   var buttonTextColor: Color = Color.white
   
   var barTextColorGreen: UIColor = UIColor(red : 48.0/255.0 ,
                                            green : 124.0/255.0 ,
                                            blue : 0.0/255.0 ,
                                            alpha : 1)
   
   var barTintColorMint: UIColor = UIColor(red : 195.0/255.0 ,
                                           green : 253.0/255.0 ,
                                           blue : 235.0/255.0 ,
                                           alpha : 1)
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         ZStack {
            Rectangle()
               .edgesIgnoringSafeArea(.all)
               .applyBackgroundGradient(accentColor: backGroundColor.opacity(0.55))
            
            
            VStack {
               Text("Welcome to help us reduce food waste and world hunger.\nShare your practical shop information in User Settings and start offering food to those in need.")
               Spacer()
            } // VStack {}
               .padding()
               .foregroundColor(accentColor)
               .font(Font.system(size : 18.0 ,
                                 weight : .semibold))
            
            
            CherrytreeWelcomeButton()
            
            CherrytreeUserSettingsButton()
            
            CherrytreeDestroyAccountButton()
            
            CherrytreeFAQButton()
            
         } // ZStack {}
            .navigationBarTitle(Text("Settings") ,
                                displayMode: .inline)
         
      } // NavigationView {}
         .accentColor(accentColor)
      
      
      
   } // var body: some View {}
   
   
   
       // ////////////////////
      //  INITIALIZER METHODS
      
      init() {
         
         // Colors the large navigation bar title :
         
         UINavigationBar
            .appearance()
            .largeTitleTextAttributes = [
               .foregroundColor : barTextColorGreen ,
               .font : UIFont(name : "ArialRoundedMTBold" , size: 40)!
         ]
         
         // Colors the navigation bar when scrolling up :
         
         UINavigationBar
            .appearance()
            .barTintColor = barTintColorMint
         
         // Colors the inline display style title :

         UINavigationBar
            .appearance()
            .titleTextAttributes = [.foregroundColor : barTextColorGreen]
         
      } // init() {}
   
   
   
} // struct CherrytreeProfileTabView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeProfileView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeSettingsTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeProfileView_Previews: PreviewProvider {}
