//
//  CherrytreeProfileView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeSettingsTabView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         ZStack(alignment : .topLeading) {
            GeometryReader { geometryProxy in
                  Image("cherriesAppIconWhite1024")
                     .resizable()
                     .scaledToFit()
                     .frame(width: geometryProxy.size.width)
                     .position(x : geometryProxy.size.width/2  ,
                               y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
        
            } // GeometryReader { geometryProxy in }
            
            
            VStack(alignment : .leading , spacing: 18.0) {
               NavigationLink(destination : CherrytreeUserProfilePage()) {
                  HStack {
                     Text("User Profile")
                     Spacer()
                  } // HStack {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
               
               NavigationLink(destination: CherrytreeYourShopPage()) {
                  HStack {
                     Text("Your Shop")
                     Spacer()
                  } // HStack {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
               
               NavigationLink(destination : CherrytreeFAQPage()) {
                  HStack {
                     Text("FAQ")
                     Spacer()
                  } // HSatck {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
            } // VStack {}
               .padding()
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold ,
                                 design : .rounded))
               .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
            
            
         } // ZStack {}
            .navigationBarTitle(Text("Settings"))
         
      } // NavigationView {}
         .accentColor(CustomColor.cherrytreeGreen.rgbColorValues)
   } // var body: some View {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      UITabBar.appearance().barTintColor = UIColor.white
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues]
   } // init() {}
   
   
   
} // struct CherrytreeProfileTabView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeProfileView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeSettingsTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeProfileView_Previews: PreviewProvider {}
