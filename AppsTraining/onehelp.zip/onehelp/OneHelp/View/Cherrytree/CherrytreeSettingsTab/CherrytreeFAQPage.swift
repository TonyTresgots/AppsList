//
//  CherrytreeFAQSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeFAQPage: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Group {
         Text("Frequently Answered Questions")
            .font(Font.system(size: 21.0 ,
                              weight: .semibold,
                              design: .rounded))
            .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
            .padding()
      } // .navigationBarItems(trailing:) {}
         .navigationBarTitle(Text("FAQ") ,
                             displayMode : .inline)
         .accentColor(CustomColor.cherrytreeGreen.rgbColorValues)
      
   } // var body: some View {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues]
      
   } // init() {}
} // struct CherrytreeFAQSheet: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeFAQPage_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeFAQPage()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeFAQSheet_Previews: PreviewProvider {}
