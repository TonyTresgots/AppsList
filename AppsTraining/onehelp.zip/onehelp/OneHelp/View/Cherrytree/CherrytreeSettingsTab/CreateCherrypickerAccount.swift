//
//  CreateCherrypickerAccount.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 15/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CreateCherrypickerAccount: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      ZStack(alignment : .topLeading) {
         VStack(alignment: .leading) {
            Text("Welcome.")
               .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
            Text("Create an account and complete your food request.")
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold ,
                                 design : .rounded))
               .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
         } // VStack(alignment:) {}
            .font(Font.system(size : 40 ,
                              weight : .semibold ,
                              design : .rounded))
            .padding()
         
         
         GeometryReader { geometryProxy in
            ZStack {
               Image("cherriesAppIconWhite1024")
                  .resizable()
                  .scaledToFit()
                  .frame(width: geometryProxy.size.width)
                  .position(x : geometryProxy.size.width/2  ,
                            y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
            } // ZStack {}
            
            
            VStack(spacing: 25) {
               NavigationLink(destination : Text("Cherrypicker account creation with Sign Up")) {
                  
                  Text("Sign Up")
                     .font(Font.system(size : 21.0 ,
                                       weight : .semibold))
                     .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                     .frame(width: geometryProxy.size.width / 1.3 ,
                            height : geometryProxy.size.height / 10)
                     .background(
                        RoundedRectangle(cornerRadius: .infinity)
                           .foregroundColor(CustomColor.cherryBlossomDark.rgbColorValues))
               } // NavigationLink(destination:) {}
               
               
               NavigationLink(destination : Text("Cherrypicker account creation with  Sign Up")) {
                  
                  Text("  Sign up with Apple")
                     .font(Font.system(size : 21.0 ,
                                       weight : .semibold))
                     .foregroundColor(Color.white)
                     .frame(width : geometryProxy.size.width / 1.3,
                            height : geometryProxy.size.height / 10)
                     .background(
                        RoundedRectangle(cornerRadius : .infinity)
                           .foregroundColor(CustomColor.blackCherry.rgbColorValues))
               } // NavigationLink(destination:) {}
            } // VStack(alignment: {}) {}
               .position(x : geometryProxy.size.width / 2  ,
                         y : geometryProxy.size.height - geometryProxy.size.width / 0.85)
            
         } // GeometryReader { geometryProxy in }
      } // ZStack {}
      
   } // var body: some View {}
} // struct CreateCherrypickerAccount: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CreateCherrypickerAccount_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CreateCherrypickerAccount()
      
      
      
   } // static var previews: some View {}
} // struct CreateCherrypickerAccount_Previews: PreviewProvider {}
