//
//  CherrypickerAddressSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeAddressSheet: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundGreen.rgbValues
   var textColor: Color = CustomColor.headerGreen.rgbValues
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      ZStack(alignment : .topLeading) {
         Rectangle()
            .edgesIgnoringSafeArea(.all)
            .applyBackgroundGradient(accentColor : backGroundColor.opacity(0.55))
         
         Group {
            Text("Cherrypicker Address Sheet")
               .font(Font.system(size: 21.0 ,
                                 weight: .semibold,
                                 design: .rounded))
               .lineSpacing(10.0)
               .foregroundColor(textColor)
         } // Group {}
            .padding()
            .padding(.top , 15)
      } // ZStack {}
      
      
      
   } // var body: some View {}
} // struct CherrypickerAddressSheet: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerAddressSheet_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeAddressSheet()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerAddressSheet_Previews: PreviewProvider {}
