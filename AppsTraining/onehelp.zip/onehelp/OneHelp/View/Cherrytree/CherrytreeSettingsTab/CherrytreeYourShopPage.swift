//
//  CherrytreeYourShopPage.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 14/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI
import MapKit



struct MapView: UIViewRepresentable {
    func makeUIView(context: UIViewRepresentableContext<MapView>)
      -> MKMapView {
         
        let mapView = MKMapView()
        return mapView
         
    } // func makeUIView(context:) -> MKMapView {}
   

    func updateUIView(_ view: MKMapView ,
                      context: UIViewRepresentableContext<MapView>) {}
} // struct MapView: UIViewRepresentable {}






struct CherrytreeYourShopPage: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var yourShopName: String = ""
   @State private var streetNameAndNumber: String = ""
   @State private var cityNameAndCityCode: String = ""
   @State private var isShowingPickupTimesSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      
      VStack {
         
         /* MAP :
          */
         
         VStack(spacing: 18.0) {
            MapView()
               .frame(width : 320.0 ,
                      height : 250.0 ,
                      alignment : .leading)
               .background(
                  RoundedRectangle(cornerRadius : 12.0)
                     .fill(Color.clear))
               .overlay(RoundedRectangle(cornerRadius : 15.0)
                  .stroke(style : StrokeStyle(lineWidth : 6.0))
                  .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues))
               .padding(.vertical)
            
            /* SHOP NAME :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if yourShopName.isEmpty {
                     HStack {
                        Spacer()
                        Text("Your shop name".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $yourShopName)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* STREET NAME AND NUMBER :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if streetNameAndNumber.isEmpty {
                     HStack {
                        Spacer()
                        Text("street name and number".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $streetNameAndNumber)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* CITY AND POSTCODE :
             */
            
            HStack {
               Spacer()
               
               ZStack {
                  if cityNameAndCityCode.isEmpty {
                     HStack {
                        Spacer()
                        Text("City and postcode".uppercased())
                           .font(Font.system(size : 13.0 ,
                                             weight : .regular))
                        Spacer()
                     } // HStack {}
                        .foregroundColor(Color.secondary)
                  } // if foodAllergy.isEmpty {}
                  
                  TextField("" , text : $cityNameAndCityCode)
                     .multilineTextAlignment(.center)
                     .disableAutocorrection(true)
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                     .padding(.vertical , 15)
                     .padding(.horizontal)
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
         } // VStack(alignment: , spacing: ) {}
            .navigationBarTitle(Text("Your Shop") , displayMode : .inline)
            .navigationBarItems(trailing : Button(action : {
               print("The Add offer button has been tapped .")
            }) {
               Image(systemName: "checkmark.circle")
                  .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
                  .font(Font.system(size : 27 ,
                                    weight : .medium))
            }) // .navigationBarItems(trailing:) {}
            .padding()
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
            .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
         
         
         
         /* PICKUP TIMES :
          */
         
         HStack {
            Spacer()
            
            Button(action : {
               self.isShowingPickupTimesSheet.toggle()
            }) {
               HStack {
                  Text("Pickup Times")
                  
                  Image(systemName: "clock.fill")
                     .font(.title)
               }
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold))
                  .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
            } // Button(action: {}) {}
               .padding()
               .padding(.bottom , 30)
               .sheet(isPresented: $isShowingPickupTimesSheet) {
                  CherrytreePickupTimesSheet()
            } // Button(action : {}) {}
            
            Spacer()
         } // .sheet(isPresented:) {}
         
         
         
      } // VStack {}
   } // var body: some View {}
} // struct CherrytreeYourShopPage: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeYourShopPage_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeYourShopPage()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeYourShopPage_Previews: PreviewProvider {}
