//
//  CherrypickerPickupTimesSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 10/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreePickupTimesSheet: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var writtenTimeTable: String = ""
   
   @State private var mondayPickupTimes: String = ""
   @State private var tuesdayPickupTimes: String = ""
   @State private var wednesdayPickupTimes: String = ""
   @State private var thursdayPickupTimes: String = ""
   @State private var fridayPickupTimes: String = ""
   @State private var saturdayPickupTimes: String = ""
   @State private var sundayPickupTimes: String = ""
      
      
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack(spacing : 15) {
         Group {
            
            /* MONDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Monday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $mondayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* TUESDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Tuesday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $tuesdayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* WEDNESDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Wednesday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $wednesdayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* THURSDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Thursday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $thursdayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
         } // Group {}
         
         
         
         Group {
            
            /* FRIDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Friday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $fridayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* SATURDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Saturday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $saturdayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            /* SUNDAY :
             */
            
            HStack {
               Spacer()
               ZStack {
                  HStack {
                     Image(systemName: "clock")
                        .foregroundColor(Color.secondary)
                        .padding(.leading)
                     
                     Text(" Sunday".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                        .foregroundColor(Color.secondary)
                     
                     TextField("" , text : $sundayPickupTimes)
                        .multilineTextAlignment(.leading)
                        .disableAutocorrection(true)
                        .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
                        .padding(.vertical , 15)
                  } // HStack {}
               } // ZStack {}
                  .overlay(
                     RoundedRectangle(cornerRadius : 8)
                        .stroke(Color.secondary ,
                                lineWidth: 1))
                  .font(Font.system(size : 18.0 ,
                                    weight : .semibold))
                  .frame(width : 320.0)
               Spacer()
            } // HStack {}
         } // Group {}
         
         
         
         /* CANCEL AND SAVE BUTTONS :
          */
         
         
         HStack {
            HStack {
               Spacer()
               
               Button(action : {
                  print("The Save button is tapped .")
               }) {
                  Text("Cancel")
                     .font(Font.system(size : 21.0 ,
                                       weight : .semibold))
                     .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
               } // Button(action: {}) {}
               
               Spacer()
            } // HStack {}
            
            
            Divider()
               .background(CustomColor.blackCherry.rgbColorValues)
            
            
            HStack {
               Spacer()
               
               Button(action : {
                  print("The Save button is tapped .")
               }) {
                  Text("Save")
                     .font(Font.system(size : 21.0 ,
                                       weight : .semibold))
                     .foregroundColor(CustomColor.cherrytreeGreen.rgbColorValues)
               } // Button(action: {}) {}
               
               Spacer()
            } // HStack {}
         } // HStack {}
            .padding(.vertical)
      } // VStack {}
         .padding()
         .padding(.top)
      
      
      
   } // var body: some View {}
   
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
   init() {
      UITableView.appearance().separatorColor = .clear
   } //  init() {
} // struct CherrytreePickupTimesSheet: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreePickupTimesSheet_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreePickupTimesSheet()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreePickupTimesSheet_Previews: PreviewProvider {}
