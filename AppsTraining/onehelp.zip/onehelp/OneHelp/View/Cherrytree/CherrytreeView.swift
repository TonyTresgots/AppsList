//
//  CherrytreeView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
    
    @EnvironmentObject var appState: AppState
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      TabView {
         CherrytreeRequestsTabView()
            .tabItem {
               Image(systemName : "hand.raised.fill")
               Text("Requests")
         } // .tabItem {}
         
         
         CherrytreeOffersTabView()
            .tabItem {
               Image(systemName : "cube.box.fill")
               Text("Offers")
         } // .tabItem {}
         
         
         CherrytreeSettingsTabView()
            .tabItem {
               Image(systemName : "person.fill")
               Text("Settings")
         } // .tabItem {}
         
      } // TabView {}
         .accentColor(CustomColor.cherrytreeGreen.rgbColorValues)
      
      
      
   } // var body: some View {}
} // struct CherrytreeView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeView_Previews: PreviewProvider {}
