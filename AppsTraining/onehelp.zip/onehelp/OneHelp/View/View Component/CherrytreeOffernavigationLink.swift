//
//  CherrytreeOfferNavigationLink.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeFoodOfferNavigationLink: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @ObservedObject var foodOffer: FoodOffer = FoodOffer(number : 11)
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Text("\(foodOffer.number)")
         .font(.largeTitle)
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferNavigationLink: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOfferNavigationLink_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeFoodOfferNavigationLink()
      
      
      
   } // static var previews: some View {{
} // struct CherrytreeOfferNavigationLink_Previews: PreviewProvider {}
