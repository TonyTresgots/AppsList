//
//  ProviderSegmentedControl.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 01/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct RequestsSegmentedControl: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var foodRequests: [FoodRequest] = foodRequestsSampleData
   var accentColor: UIColor
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var statusIndex = 0
   
   @State private var status = [
      NSLocalizedString("Pending" , comment : "") ,
      NSLocalizedString("Accepted" , comment : "") ,
      NSLocalizedString("Declined" , comment : "")
   ] // @State private var status = []
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var statusPicked: [FoodRequest] {
      foodRequests.filter { $0.status.rawValue == status[statusIndex] }
   } // var statusPicked: [Request] {}
   
   
   
   var body: some View {
      
      Picker(selection : $statusIndex ,
             label : Text("Text")) {
               
               ForEach(0..<status.count) { index in
                  Text(self.status[index]).tag(index)
               } // ForEach({ {}
               
      } // Picker(selection) {}
         .pickerStyle(SegmentedPickerStyle())
         .padding(.horizontal)
      
      
      
   } // var body: some View {}
   
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
   init(accentColor: UIColor) {
      self.accentColor = accentColor
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = accentColor
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : accentColor] ,
                                 for : .normal)
   } // init() {}
   
   
   
} // struct ProviderSegmentedControl: View {}





 // ///////////////
//  MARK: PREVIEWS

struct ProviderSegmentedControl_Previews: PreviewProvider {
   
   static var previews: some View {
      
      RequestsSegmentedControl(accentColor: CustomUIColor.cherrypickerRedUI.rgbUIColorValues)
      
      
      
   } // static var previews: some View {}
} // struct ProviderSegmentedControl_Previews: PreviewProvider {}
