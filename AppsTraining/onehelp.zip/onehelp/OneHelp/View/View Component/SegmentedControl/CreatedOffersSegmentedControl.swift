//
//  CreatedOffersSegmentedControl.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CreatedOffersSegmentedControl: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var offers: [FoodOffer] = foodOffersSampleData
   var accentColor: UIColor
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var dateCreationIndex = 0
   
   @State private var dateCreation = [
      NSLocalizedString("Today" , comment : "") ,
      NSLocalizedString("This week" , comment : "") ,
      NSLocalizedString("This month" , comment : "")
   ] // @State private var status = []
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var statusPicked: [FoodOffer] {
      foodOffersSampleData.filter { $0.creationDateCategory == dateCreation[dateCreationIndex] }
   } // var statusPicked: [Request] {}
   
   
   
   var body: some View {
      
      Picker(selection : $dateCreationIndex ,
             label : Text("Text")) {
               
               ForEach(0..<dateCreation.count) { index in
                  Text(self.dateCreation[index]).tag(index)
               } // ForEach({ {}
               
      } // Picker(selection) {}
         .pickerStyle(SegmentedPickerStyle())
         .padding(.horizontal)
      
      
      
   } // var body: some View {}
   
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
   init(accentColor: UIColor) {
      self.accentColor = accentColor
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = accentColor
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes(
            [.foregroundColor : accentColor] ,
            for : .normal)
   } // init() {}} // var body: some View {}
} // struct CreatedOffersSegmentedControl: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CreatedOffersSegmentedControl_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CreatedOffersSegmentedControl(accentColor : CustomUIColor.cherrytreeGreenUI.rgbUIColorValues)
      
      
      
   } // static var previews: some View {}
} // struct CreatedOffersSegmentedControl_Previews: PreviewProvider {}
