//
//  CompanyAddress.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CompanyAddress: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var accentColor: Color
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack(alignment : .leading) {
         Text("address".uppercased())
            .fontWeight(.bold)
            .font(.caption)
            .foregroundColor(self.accentColor)
            .padding(.bottom , 10)
         
         
         VStack(alignment : .leading , spacing : 5) {
            Text("Via Rue Moliere 12 a bis")
            Text("Napoli 80121")
            Text("Italy")
            
            HStack {
               Image(systemName: "phone.fill")
               Text("0123456789")
            } // HStack
         } // VStack(alignment : .leading) {}
            .font(Font.system(size : 15.0 ,
                              weight : .regular))
            .foregroundColor(Color.secondary)
      } // VStack() {}
      
      
      
   } // var body: some View {}
} // struct CompanyAddress: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CompanyAddress_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CompanyAddress(accentColor : CustomColor.cherrytreeGreen.rgbColorValues)
      
      
      
   } // static var previews: some View {}
} // struct CompanyAddress_Previews: PreviewProvider {}
