//
//  PickupTimeTable.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI

struct PickupTimeTable: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var accentColor: Color
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {

      VStack(alignment : .leading) {
         Text("pickup time".uppercased())
            .fontWeight(.bold)
            .font(.caption)
            .foregroundColor(self.accentColor)
            .padding(.bottom , 10)
         
         
         VStack(alignment : .leading) {
            
            VStack(alignment : .leading , spacing : 5) {
               HStack(alignment : .center) {
                  Text("Monday")
                     .foregroundColor(Color.secondary)
                     .font(Font.system(size : 15.0 ,
                                       weight : .light))
                  Spacer()
                  Text("14:00 - 17:00")
                     .foregroundColor(accentColor)
                     .fontWeight(.medium)
               } // HStack {}
               
               
               HStack(alignment: .center) {
                  Text("Tuesday - Friday")
                     .foregroundColor(Color.secondary)
                     .font(Font.system(size : 15.0 ,
                                       weight : .light))
                  Spacer()
                  Text("16:00 - 19:00")
                     .foregroundColor(self.accentColor)
                     .fontWeight(.medium)
               } // HStack {}
               
               
               HStack(alignment: .center) {
                  Text("Saturday")
                     .foregroundColor(Color.secondary)
                     .font(Font.system(size : 15.0 ,
                                       weight : .light))
                  Spacer()
                  Text("09:00 - 11:00")
                     .foregroundColor(accentColor)
                     .fontWeight(.medium)
               } // HStack {}
               
               
               HStack(alignment: .center) {
                  Text("Sunday")
                     .foregroundColor(Color.secondary)
                     .font(Font.system(size : 15.0 ,
                                       weight : .light))
                  Spacer()
                  Text("No Food Pickup".uppercased())
                     .foregroundColor(accentColor)
                     .font(Font.system(size : 13.0 ,
                                       weight : .medium))
               } // HStack {}
            } // VStack {}
               .foregroundColor(Color.secondary)
               .font(.subheadline)
         }
      } // VStack(alignment: , spacing:) {}
      
      
      
   } // var body: some View {}
} // struct PickupTimeTable: View {}





 // ///////////////
//  MARK: PREVIEWS

struct PickupTimeTable_Previews: PreviewProvider {
   
   static var previews: some View {
      
      PickupTimeTable(accentColor : CustomColor.cherrytreeGreen.rgbColorValues)
      
      
      
   } // static var previews: some View {}
} // struct PickupTimeTable_Previews: PreviewProvider {}
