//
//  CherrytreeRequestedFoodListItem.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeRequestedFoodListItem: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var name: String = "George Cherrytree"
   var buttonHeight: CGFloat = 90.0
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var foodOffer: FoodOffer
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
         Text(self.foodOffer.dateCreated.uppercased())
            .font(.caption)
            .foregroundColor(CustomColor.blackCherry.rgbColorValues)
            .position(x : geometryProxy.size.width / 2 ,
                      y : geometryProxy.size.height / 6)
         
         
         HStack {
            Text(self.foodOffer.shopName)
               .font(Font.system(size : 16.0 ,
                                 weight : .medium,
                                 design : .rounded))
               .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
               .padding(.leading)
            
            
            Spacer()
            
            
            if self.foodOffer.imageName == "cube.box.fill" {
               
               ZStack {
                  Circle()
                     .foregroundColor(
                        CustomColor.cherryBlossom.rgbColorValues)
                     .overlay(
                        Circle()
                           .strokeBorder(CustomColor.cherrypickerRedLight.rgbColorValues ,
                                         lineWidth : 3))
                     
                  
                  Image(systemName: "cube.box.fill")
                     .font(.title)
                     .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
               } // ZStack {}
                  .frame(width : self.buttonHeight ,
                         height : self.buttonHeight)
               
            } else {
               
               Image(self.foodOffer.imageName)
                  .renderingMode(.original)
                  .resizable()
                  .frame(width : self.buttonHeight ,
                         height : self.buttonHeight)
                  .scaledToFit()
                  .clipShape(RoundedRectangle(cornerRadius : .infinity))
               
            } // if self.foodOffer.imageName == "cube.box.fill" {}
         } // HStack {}
         
         
         Text("OFFER \(self.foodOffer.number)")
            .font(.caption)
            .foregroundColor(Color.secondary)
            .position(x : geometryProxy.size.width / 2 ,
                      y : geometryProxy.size.height / 1.2)
         
      } // GeometryReader { geometryProxy in }
         .frame(height : self.buttonHeight)
         .background(
            RoundedRectangle(cornerRadius : .infinity)
               .strokeBorder(CustomColor.cherrypickerRedDark.rgbColorValues ,
                             lineWidth : 1))
      
      
      
   } // var body: some View {}
} // struct CherrytreeRequestedFoodListItem: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeRequestedFoodListItem_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeRequestedFoodListItem(foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                            number : 100 ,
                                                            info : "Info exemple" ,
                                                            pickupTime : "Monday morning" ,
                                                            dateCreated : "2 September" ,
                                                            creationDateCategory : "Today" ,
                                                            distance : "2 km",
                                                            shopName : "Carmina Food"))
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeRequestedFoodListItem_Previews: PreviewProvider {}
