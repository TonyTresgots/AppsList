//
//  CherrypickerListItem.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerFoodListItem: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var buttonHeight: CGFloat = 90.0
//   var foodOffer2: FoodOffer
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   var foodRequest: FoodRequest
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
        Text(self.foodRequest.offer.dateCreated.uppercased())
            .font(.caption)
            .foregroundColor(Color.secondary)
            .position(x : geometryProxy.size.width / 2 ,
                      y : geometryProxy.size.height / 6)
         
         
         HStack {
            Text(self.foodRequest.name)
               .font(Font.system(size : 16.0 ,
                                 weight : .medium,
                                 design : .rounded))
               .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
               .padding(.leading)
            
            
            Spacer()
            
            
            if self.foodRequest.offer.imageName == "cube.box.fill" {
               
               ZStack {
                  Circle()
                     .foregroundColor(
                        CustomColor.cherryLeafMintLight.rgbColorValues)
                     .overlay(
                        Circle()
                           .strokeBorder(CustomColor.cherrytreeGreen.rgbColorValues ,
                                         lineWidth : 3))
                  
                  Image(systemName: "cube.box.fill")
                     .font(.title)
                     .foregroundColor(CustomColor.cherrytreeGreenDark.rgbColorValues)
               } // ZStack {}
                  .frame(width : self.buttonHeight ,
                         height : self.buttonHeight)
               
            } else {
               
               Image(self.foodRequest.offer.imageName)
                  .renderingMode(.original)
                  .resizable()
                  .frame(width : self.buttonHeight ,
                         height : self.buttonHeight)
                  .scaledToFit()
                  .clipShape(RoundedRectangle(cornerRadius : .infinity))
               
            } // if self.foodOffer.imageName == "cube.box.fill" {}
         } // HStack {}
         
         
         //        if self.cher.allergies.isEmpty {
         //
         //            Text("")
         //
         //         } else {
         
         //            Text("ALLERGIC TO \(self.cherryPicker.allergies[0].uppercased())")
         Text("ALLERGIC TO GLUTEN")
            .font(.caption)
            .foregroundColor(CustomColor.blackCherry.rgbColorValues)
            .position(x : geometryProxy.size.width / 2 ,
                      y : geometryProxy.size.height / 1.2)
         
         // } // if self.cherryPicker.allergies.isEmpty {} else {}
      } // GeometryReader { geometryProxy in }
         .frame(height : self.buttonHeight)
         .background(
            RoundedRectangle(cornerRadius : .infinity)
               .strokeBorder(CustomColor.cherrytreeGreenDark.rgbColorValues ,
                             lineWidth : 1))
      
      
      
   } // var body: some View {}
} // struct CherrypickerListItem: View {}

