//
//  FoodOfferDescription.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct FoodOfferDescription: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var accentColor: Color
   var offer: FoodOffer
   var titleColor: Color
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack(alignment : .leading) {
        Text("Offer number \(offer.number)".uppercased())
            .fontWeight(.bold)
            .font(.caption)
            .foregroundColor(titleColor)
            .padding(.vertical , 10)
         
         
        Text(offer.info)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold))
            .foregroundColor(accentColor)
      } // VStack() {}
      
      
      
      
      
   } // var body: some View {}
} // struct FoodOfferDescription: View {}





 // ///////////////
//  MARK: PREVIEWS

struct FoodOfferDescription_Previews: PreviewProvider {
   
   static var previews: some View {
      
    FoodOfferDescription(accentColor : CustomColor.headerGreen.rgbColorValues ,
                         offer : FoodOffer(nameOfferer : "" ,
                                           number : 0 ,
                                           info : "" ,
                                           pickupTime : "" ,
                                           dateCreated : "" ,
                                           creationDateCategory : "" ,
                                           distance : "",
                                           shopName : "Carmina Food") ,
                         titleColor : Color.accentColor)

      
      
   } // static var previews: some View {}
} // struct FoodOfferDescription_Previews: PreviewProvider {}
