//
//  RedWelcomeButton.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerIDSettingsButton: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var alertColor: Color = CustomColor.backgroundRed.rgbValues
   var accentColor: Color = CustomColor.alertRed.rgbValues
   var textColor: Color = Color.white
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var isShowingWelcomeSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
         Button(action: {
            print("The Welcome button is tapped .")
            self.isShowingWelcomeSheet.toggle()
         }) {
            
            ZStack {
               Circle()
                  .frame(width : geometryProxy.size.width/2 ,
                         height : geometryProxy.size.width/2)
               
               Text("ID\nSettings").multilineTextAlignment(.center)
                  .foregroundColor(self.textColor)
            } // ZStack {}
               .position(x : geometryProxy.size.width / 3.99 ,
                         y : geometryProxy.size.height - geometryProxy.size.width/1.335)
            
         } // Button(action: {}) {}
            .buttonStyle(PlainButtonStyle())
            .sheet(isPresented : self.$isShowingWelcomeSheet) {
               CherrypickerWelcomeSheet()
         } // .sheet(isPresented:) {}
            .foregroundColor(self.accentColor)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
      } // .sheet(isPresented:) {}
      
      
      
   } // var body: some View {}
} // struct RedWelcomeButton: View {}





 // ///////////////
//  MARK: PREVIEWS

struct RedWelcomeButton_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerIDSettingsButton()
      
      
      
   } // static var previews: some View {}
} // struct RedWelcomeButton_Previews: PreviewProvider {}
