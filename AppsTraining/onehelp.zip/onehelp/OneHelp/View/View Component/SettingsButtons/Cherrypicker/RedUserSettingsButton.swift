//
//  RedUserSettingsButton.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerUserSettingsButton: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var accentColor: Color = CustomColor.backgroundRed.rgbValues
   var alertColor: Color = CustomColor.alertRed.rgbValues
   var textColor: Color = Color.white
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var isShowingUserSettingsSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
         Button(action: {
            print("The User Settings button is tapped .")
            self.isShowingUserSettingsSheet.toggle()
         }) {
            
            ZStack {
                  Circle()
                     .frame(width : geometryProxy.size.width/2 ,
                            height : geometryProxy.size.width/2)
                  Text("User\nSettings").multilineTextAlignment(.center)
                     .foregroundColor(self.textColor)
               } // ZStack {}
                  .position(x : geometryProxy.size.width/1.335 ,
                            y : geometryProxy.size.height - geometryProxy.size.width/1.335)
               
            } // Button(action: {}) {}
            .buttonStyle(PlainButtonStyle())
            .sheet(isPresented : self.$isShowingUserSettingsSheet) {
               CherrypickerUserSettingsSheet()
         } // .sheet(isPresented:) {}
            .foregroundColor(self.accentColor)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
      } // .sheet(isPresented:) {}}
      
      
      
   } // var body: some View {}
} // struct RedUserSettingsButton: View {}





 // ///////////////
//  MARK: PREVIEWS

struct RedUserSettingsButton_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerUserSettingsButton()
      
      
      
   } // static var previews: some View {}
} // struct RedUserSettingsButton_Previews: PreviewProvider {}
