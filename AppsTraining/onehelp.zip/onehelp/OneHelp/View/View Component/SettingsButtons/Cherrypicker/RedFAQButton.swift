//
//  RedFAQButton.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI

struct CherrypickerFAQButton: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var accentColor: Color = CustomColor.backgroundRed.rgbValues
   var alertColor: Color = CustomColor.alertRed.rgbValues
   var textColor: Color = Color.white
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var isShowingContactUsSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
         Button(action: {
            print("The FAQ button is tapped .")
            self.isShowingContactUsSheet.toggle()
         }) {
            
            ZStack {
               Circle()
                  .frame(width : geometryProxy.size.width/2 ,
                         height : geometryProxy.size.width/2)
               
               Text("FAQ").multilineTextAlignment(.center)
                  .foregroundColor(self.textColor)
            } // ZStack {}
               .position(x : geometryProxy.size.width/1.335 ,
                         y : geometryProxy.size.height - geometryProxy.size.width/4)
            
         } // Button(action: {}) {}
            .buttonStyle(PlainButtonStyle())
            .sheet(isPresented : self.$isShowingContactUsSheet) {
               CherrypickerFAQSheet()
         } // .sheet(isPresented:) {}
            .foregroundColor(self.accentColor)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
      } // .sheet(isPresented:) {}}
      
      
      
   } // var body: some View {}
} // struct RedFAQButton: View {}





 // ///////////////
//  MARK: PREVIEWS

struct RedFAQButton_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerFAQButton()
      
      
      
   } // static var previews: some View {}
} // struct RedFAQButton_Previews: PreviewProvider {}
