//
//  RedDestroyAccountSheet.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct RedDestroyAccountButton: View {
   
   // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var accentColor: Color = CustomColor.backgroundRed.rgbValues
   var alertColor: Color = CustomColor.alertRed.rgbValues
   var textColor: Color = Color.white
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var isShowingAccountSettingsSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         
         Button(action: {
            print("The Destroy Account button is tapped .")
            self.isShowingAccountSettingsSheet.toggle()
         }) {
            
            ZStack {
                  Circle()
                     .frame(width : geometryProxy.size.width/2 ,
                            height : geometryProxy.size.width/2)
                  
                  Text("Destroy\nAccount").multilineTextAlignment(.center)
                     .foregroundColor(self.textColor)
               } // ZStack {}
                  .position(x : geometryProxy.size.width / 3.99 ,
                            y : geometryProxy.size.height - geometryProxy.size.width/4)
                  .foregroundColor(self.alertColor)
               
            } // Button(action: {}) {}
            .buttonStyle(PlainButtonStyle())
            .sheet(isPresented : self.$isShowingAccountSettingsSheet) {
               CherrypickerAccountSettingsSheet()
         } // .sheet(isPresented:) {}
            .foregroundColor(self.alertColor)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold ,
                              design : .rounded))
      } // .sheet(isPresented:) {}}
      
      
      
   } // var body: some View {}
} // var body: some View {}} // struct RedDestroyAccountSheet: View {}





 // ///////////////
//  MARK: PREVIEWS

struct RedDestroyAccountSheet_Previews: PreviewProvider {
   
   static var previews: some View {
      
      RedDestroyAccountButton()
      
      
      
   } // static var previews: some View {}
} // struct RedDestroyAccountSheet_Previews: PreviewProvider {}
