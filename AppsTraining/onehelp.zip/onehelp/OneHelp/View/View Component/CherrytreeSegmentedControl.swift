//
//  ReceiverSegmentedControl.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 01/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct OffersSegmentedControl: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var offers: [FoodOffer] = foodOffersSampleData
   var accentColor: UIColor
   
//   var textColor: UIColor = UIColor(red : 186.0/255.0 ,
//                                    green : 0.0/255.0 ,
//                                    blue : 32.0/255.0 ,
//                                    alpha : 1)
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var distanceIndex = 0
   
   @State private var distance = [
      NSLocalizedString("2 km" , comment : "") ,
      NSLocalizedString("5 km" , comment : "") ,
      NSLocalizedString("10+ km" , comment : "")
   ] // @State private var status = []
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var statusPicked: [FoodOffer] {
      foodOffersSampleData.filter { $0.distance.rawValue == distance[distanceIndex] }
   } // var statusPicked: [Request] {}
   
   
   
   var body: some View {
      
      Picker(selection : $distanceIndex ,
             label : Text("Text")) {
               
               ForEach(0..<distance.count) { index in
                  Text(self.distance[index]).tag(index)
               } // ForEach({ {}
               
      } // Picker(selection) {}
         .pickerStyle(SegmentedPickerStyle())
         .padding(.horizontal)
      
      
      
   } // var body: some View {}
   
   
   
    // //////////////////////////
   //  MARK: INITIALIZER METHODS
   
   init(accentColor: UIColor) {
      self.accentColor = accentColor
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = accentColor
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes(
            [.foregroundColor : accentColor] ,
            for : .normal)
   } // init() {}
   
   
   
} // struct ReceiverSegmentedControl: View {}





 // ///////////////
//  MARK: PREVIEWS

struct ReceiverSegmentedControl_Previews: PreviewProvider {
   
   static var previews: some View {
      
      OffersSegmentedControl(accentColor : UIColor(red : 186.0/255.0 ,
                                                       green : 0.0/255.0 ,
                                                       blue : 32.0/255.0 ,
                                                       alpha : 1))
      
      
      
   } // static var previews: some View {}
} // struct ReceiverSegmentedControl_Previews: PreviewProvider {}
