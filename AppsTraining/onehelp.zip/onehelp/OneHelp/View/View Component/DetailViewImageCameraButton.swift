//
//  DetailViewImageCameraButton.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct DetailViewImageCameraButton: View {
      
    // /////////////////
   //  MARK: PROPERTIES
      
   var accentColor: Color
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var foodOffer: FoodOffer = FoodOffer(nameOfferer: "Davide",number : 100, info: "Info exemple", pickupTime: "Monday morning", dateCreated: "2 Sept.", creationDateCategory: "Today", distance: "2 km")
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      
      Button(action : {
         print("The Camera Button is tapped .")
      }) {
         
         GeometryReader { geometryProxy in
            ZStack {
               Circle()
                  .foregroundColor(Color.clear)
                  .overlay(
                     Circle()
                        .stroke(style : StrokeStyle(lineWidth : 9.0))
                        .foregroundColor(self.accentColor))
                  .frame(width : geometryProxy.size.width ,
                         height : geometryProxy.size.width ,
                         alignment : .center)
               
               
               Image(systemName: "camera.fill")
                  .font(.largeTitle)
                  .foregroundColor(self.accentColor)
            } // ZStack {}
         } // GeometryReader { geometryProxy in }
         
      } // Button(action: {}) {}
      
      
      
      
   } // var body: some View {}
} // struct DetailViewImageCameraButton: View {}





 // ///////////////
//  MARK: PREVIEWS

struct DetailViewImageCameraButton_Previews: PreviewProvider {
   
   static var previews: some View {
      
      DetailViewImageCameraButton(accentColor : CustomColor.headerGreen.rgbColorValues)
      
      
      
   } // static var previews: some View {}
} // struct DetailViewImageCameraButton_Previews: PreviewProvider {}
