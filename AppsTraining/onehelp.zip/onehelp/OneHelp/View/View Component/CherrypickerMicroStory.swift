//
//  CherrypickerMicroStory.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerMicroStory: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
    
   var request : FoodRequest
   
   var body: some View {
      
    Text("\(request.name) lives in a household with three dependants. There are no known food allergies. The last food collection was three days ago.")
      
      
      
   } // var body: some View {}
} // struct CherrypickerMicroStory: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerMicroStory_Previews: PreviewProvider {
   
   static var previews: some View {
      
    CherrypickerMicroStory(request: FoodRequest(name: "", status: .approved, date: "", statusString: "", offer: FoodOffer(nameOfferer: "", number: 0, info: "", pickupTime: "", dateCreated: "", creationDateCategory: "", distance: "",
    shopName : "Carmina Food")))
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerMicroStory_Previews: PreviewProvider {}
