//
//  DetailViewImageFrame.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 06/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct DetailViewImageFrame: View {
      
    // /////////////////
   //  MARK: PROPERTIES
      
   var accentColor: Color
   var iconImageColor: Color
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var foodOffer: FoodOffer
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      GeometryReader { geometryProxy in
         ZStack {
            
            if self.foodOffer.imageName == "cube.box.fill" {
               
               Circle()
                  .foregroundColor(Color.clear)
                  .overlay(
                     Circle()
                        .stroke(style : StrokeStyle(lineWidth : 9.0))
                        .foregroundColor(self.accentColor))
                  .frame(width : geometryProxy.size.width ,
                         height : geometryProxy.size.width ,
                         alignment : .center)
               Image(systemName: "photo")
                  .font(.largeTitle)
                  .foregroundColor(self.iconImageColor)
               
            } else {
               
               Image(self.foodOffer.imageName)
                  .resizable()
                  .scaledToFit()
                  .frame(width : geometryProxy.size.width ,
                         height : geometryProxy.size.width ,
                         alignment : .center)
               .clipShape(Circle())
               .overlay(
                  Circle()
                     .stroke(style: StrokeStyle(lineWidth : 9.0))
                     .foregroundColor(self.accentColor))
               
            } // if self.foodOffer.imageName == "cube.box.fill" {} else {}
            
         } // ZStack {}
      } // GeometryReader { geometryProxy in }
      
      
      
   } // var body: some View {}
} // struct DetailViewImageFrame: View {}





 // ///////////////
//  MARK: PREVIEWS

struct DetailViewImageFrame_Previews: PreviewProvider {
   
   static var previews: some View {
      
      Group {
        DetailViewImageFrame(accentColor : CustomColor.backgroundRed.rgbColorValues ,
                             iconImageColor : Color.accentColor ,
                             foodOffer : FoodOffer(imageName : "eggs",
                                                   nameOfferer : "Name Offerer" ,
                                                   number : 100 ,
                                                   info : "Info example" ,
                                                   pickupTime : "Monday morning" ,
                                                   dateCreated : "2 September" ,
                                                   creationDateCategory : "Today" ,
                                                   distance : "2 km",
                                                   shopName : "Carmina Food"))
         
        DetailViewImageFrame(accentColor : CustomColor.backgroundRed.rgbColorValues ,
                             iconImageColor : Color.accentColor ,
                              foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                    number : 100 ,
                                                    info : "Info example" ,
                                                    pickupTime : "Monday morning" ,
                                                    dateCreated : "2 September" ,
                                                    creationDateCategory : "Today" ,
                                                    distance : "2 km",
                                                    shopName : "Carmina Food"))

      } // Group {}
   } // static var previews: some View {}
} // struct DetailViewImageFrame_Previews: PreviewProvider {}
