//
//  CherrytreeOfferNavigationLink.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeFoodOfferNavigationLink: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
    var foodOffer: FoodOffer
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      CherrytreeRequestedFoodListItem(foodOffer : foodOffer)
         .padding(.top , 12)
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferNavigationLink: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOfferNavigationLink_Previews: PreviewProvider {
   
   static var previews: some View {
      
    CherrytreeFoodOfferNavigationLink(foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                            number : 1 ,
                                                            info : "" ,
                                                            pickupTime : "" ,
                                                            dateCreated : "" ,
                                                            creationDateCategory : "" ,
                                                            distance : "",
                                                            shopName : "Carmina Food"))
      
      
      
   } // static var previews: some View {{
} // struct CherrytreeOfferNavigationLink_Previews: PreviewProvider {}
