//
//  CherrypickerFoodRequestNavigationLink.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerFoodRequestNavigationLink: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
    var foodRequest : FoodRequest
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
    CherrypickerFoodListItem(foodRequest: foodRequest)
         .padding(.top , 12)
      
      
      
   } // var body: some View {}
} // struct CherrypickerFoodRequestNavigationLink: View {}
