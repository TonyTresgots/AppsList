//
//  CherrytreeCreatedFoodOfferNavigationLink.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 15/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeCreatedFoodOfferNavigationLink: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   var foodOffer: FoodOffer 
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      CherrytreeCreatedFoodOfferListItem(foodOffer : foodOffer)
         .padding(.top , 12)
      
   } // var body: some View {}
} // struct CherrytreeCreatedFoodOfferNavigationLink: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeCreatedFoodOfferNavigationLink_Previews: PreviewProvider {
   
   static var previews: some View {
      
    CherrytreeCreatedFoodOfferNavigationLink(foodOffer: FoodOffer(nameOfferer: "", number: 0, info: "", pickupTime: "", dateCreated: "", creationDateCategory: "", distance: "",
    shopName : "Carmina Food"))
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeCreatedFoodOfferNavigationLink_Previews: PreviewProvider {}
