//
//  CherrypickerProfileView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerProfileTabView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Text("Cherrypicker Profile View")
      
      
      
   } // var body: some View {}
} // struct CherrypickerProfileView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerProfileView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerProfileTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerProfileView_Previews: PreviewProvider {}
