//
//  CherrypickerView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerView: View {
    
    @EnvironmentObject var appState: AppState
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      TabView {
         CherrypickerRequestsTabView()
            .tabItem {
               Image(systemName : "hand.raised.fill")
               Text("Requests")
         } // .tabItem {}
         
         
         CherrypickerOffersTabView()
            .tabItem {
               Image(systemName : "cube.box.fill")
               Text("Offers")
         } // .tabItem {}
         
         
         CherrypickerSettingsTabView()
            .tabItem {
               Image(systemName : "person.fill")
               Text("Settings")
         } // .tabItem {}
         
      } // TabView {}
         .accentColor(CustomColor.cherrypickerRedLight.rgbColorValues)
      
      
      
      
   } // var body: some View {} 
} // struct CherrypickerView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerView()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerView_Previews: PreviewProvider {}
