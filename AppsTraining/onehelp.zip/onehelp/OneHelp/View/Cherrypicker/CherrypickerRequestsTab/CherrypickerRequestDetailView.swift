//
//  CherrytreeOfferDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerRequestDetailView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var foodReq: FoodRequest
   @State private var showingAlert = false
   @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var indexArray: Int
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
               
         List {
            VStack(alignment : .center) {
               
               DetailViewImageFrame(accentColor : CustomColor.cherrypickerRedLight.rgbColorValues ,
                                    iconImageColor : CustomColor.cherrypickerRed.rgbColorValues ,
                                    foodOffer : foodReq.offer)
                  .frame(width : 320 ,
                         height : 320 ,
                         alignment : .center)
                  .padding(.top)
               
               
               VStack(alignment : .leading) {
                FoodOfferDescription(accentColor : CustomColor.cherrypickerRedLight.rgbColorValues, offer : foodReq.offer, titleColor : CustomColor.cherrypickerRed.rgbColorValues)
                     
                PickupTimeTable(accentColor : CustomColor.cherrypickerRedLight.rgbColorValues)
                     .padding(.vertical , 20)
                  
                  CompanyAddress(accentColor : CustomColor.cherrypickerRed.rgbColorValues)
               } // VStack(alignment: .leading) { {}
            } // VStack(alignment: .center) { {}
               .padding(.horizontal , 8)
         } // List {}
            .navigationBarTitle(Text(foodReq.offer.shopName) ,
                             displayMode : .inline)
         .navigationBarItems(trailing : Button(action : {
            print("The Decline offer button has been tapped .")
            self.showingAlert = true
         }) {
            if foodReq.statusString == "Pending" {
                Image(systemName: "bin.xmark.fill")
                .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                .font(Font.system(size : 27 ,
                                  weight : .medium))
            }
            
         }) // .navigationBarItems(trailing:) {}
    .alert(isPresented: $showingAlert) {
        Alert(title: Text("Request removed"), message: Text("You successfully removed this request !"), dismissButton: .default(Text("Ok")) {
           //     self.foodReq.statusString = "Declined"
                foodRequestsSampleData.remove(at: self.indexArray)
                self.presentationMode.wrappedValue.dismiss()
            })
    }
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

//struct CherrytreeRequestDetailView_Previews: PreviewProvider {
//
//   static var previews: some View {
//
//
//      Group {
//         CherrypickerRequestDetailView(foodOffer : FoodOffer(nameOfferer : "Davide" ,
//                                                             number : 100 ,
//                                                             info : "Info example" ,
//                                                             pickupTime : "Monday morning" ,
//                                                             dateCreated : "2 September" ,
//                                                             creationDateCategory : "Today" ,
//                                                             distance : "2 km",
//                                                             shopName : "Carmina Food"))
//            .previewDevice(PreviewDevice(rawValue : "iPhone XS Max"))
//            .previewDisplayName("iPhone XS Max")
//
//         CherrypickerRequestDetailView(foodOffer : FoodOffer(nameOfferer : "Davide" ,
//                                                             number : 100 ,
//                                                             info : "Info example" ,
//                                                             pickupTime : "Monday morning" ,
//                                                             dateCreated : "2 September" ,
//                                                             creationDateCategory : "Today" ,
//                                                             distance : "2 km",
//                                                             shopName : "Carmina Food"))
//            .previewDisplayName("iPhone 8")
//      } // Group {}
//   } // struct CherrytreeOfferDetailView_Previews: PreviewProvider {}
//} // struct CherrytreeRequestDetailView_Previews: PreviewProvider {}
