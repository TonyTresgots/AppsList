//
//  CherrytreeOffersView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerRequestsTabView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @ObservedObject var cherrytree: Cherrytree = Cherrytree()
   
   @State private var statusIndex = 0
   
   @State private var status = [
      NSLocalizedString("Pending" , comment : "") ,
      NSLocalizedString("Accepted" , comment : "") ,
      NSLocalizedString("Declined" , comment : "")
   ] // @State private var status = []
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var statusPicked: [FoodRequest] {
      foodRequestsSampleData.filter { $0.statusString == status[statusIndex] }
   } // var statusPicked: [Request] {}
   
   
   var body: some View {
      
      NavigationView {
            List {
               Picker(selection : $statusIndex ,
                      label : Text("Text")) {
                        
                        ForEach(0..<status.count) { index in
                           Text(self.status[index]).tag(index)
                        } // ForEach({ {}
                        
               } // Picker(selection) {}
                  .pickerStyle(SegmentedPickerStyle())
                  .padding(.bottom , 5)
            
               
               ForEach(statusPicked) { foodOffer in
                NavigationLink(destination : CherrypickerRequestDetailView(foodReq : foodOffer, indexArray: foodRequestsSampleData.firstIndex(where: {$0 === foodOffer}) ?? 0)) {
                     
                     CherrytreeFoodOfferNavigationLink(foodOffer : foodOffer.offer)
                     
                  } // NavigationLink(destination:) {}
               } // ForEach() {}
                  .onDelete(perform : removeFoodOfferRows)
               
            } // List() {}
           //    .id(UUID())
               .navigationBarTitle(Text("Requests"))
      } // NavigationView {}
         .accentColor(CustomColor.cherrypickerRed.rgbColorValues)
      
      
      
   } // var body: some View {}
   
   
   
   
    // //////////////
   //  MARK: METHODS
   
   func removeFoodOfferRows(at offsets: IndexSet) {
      /* Because our ForEach was created entirely from a single array ,
       * we can actually just pass that index set
       * straight to our numbers array
       * – it has a special remove(atOffsets:) method
       * that accepts an index set :
       */
      foodRequestsSampleData.remove(atOffsets : offsets)
   } // func removeRows(at offsets:) {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      UITableView.appearance().separatorStyle = .none
      UITableView.appearance().backgroundColor = .clear
      UITableViewCell.appearance().backgroundColor = .clear
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues]
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = CustomUIColor.cherrypickerRedUI.rgbUIColorValues
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : CustomUIColor.cherrypickerRedDarkUI.rgbUIColorValues] ,
                                 for : .normal)
   } // init() {}
   
   
} // struct CherrytreeOffersView: View {}




// ///////////////
//  MARK: PREVIEWS

struct CherrytreeOffersView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerRequestsTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeOffersView_Previews: PreviewProvider {}
