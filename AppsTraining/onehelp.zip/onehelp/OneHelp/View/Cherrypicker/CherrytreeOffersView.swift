//
//  CherrytreeOffersView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI

struct CherrytreeOffersTabView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         
         TabView {
            
            VStack(alignment : .leading , spacing : 20.0) {
               NavigationLink(destination : Text("Cherrytree offer detail view")) {
                  Text("Hello 👋 World 🌍")
               } // NavigationLink(destination:) {}
               
               NavigationLink(destination : Text("Cherrytree offer detail view")) {
                  Text("Hello 👋 Again")
               } // NavigationLink(destination:) {}
            } // VStack {}
               .tabItem {
                  Image(systemName : "tray.and.arrow.down.fill")
                  Text("Food Givers")
            } // .tabItem {}
            
            
            CherrypickerProfileTabView()
               .tabItem {
                  Image(systemName : "person.crop.circle.fill")
                  Text("Your Profile")
            } // .tabItem {}
            
         } // TabView {}
            .navigationBarTitle("Cherrytrees")
         
         
      } // NavigationView {}
      
      
      
   } // var body: some View {}
} // struct CherrytreeOffersView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOffersView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeOffersTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeOffersView_Previews: PreviewProvider {}
