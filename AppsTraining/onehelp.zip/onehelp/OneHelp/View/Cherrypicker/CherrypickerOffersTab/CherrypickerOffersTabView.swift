//
//  CherrypickerOffersTabView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerOffersTabView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @ObservedObject var cherrytree: Cherrytree = Cherrytree()
   
   @State private var statusIndex = 0
   
   @State private var status = [
      NSLocalizedString("2 km" , comment : "") ,
      NSLocalizedString("5 km" , comment : "") ,
      NSLocalizedString("10+ km" , comment : "")
   ] // @State private var status = []
   
   
   
     // //////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var statusPicked: [FoodOffer] {
        foodOffersSampleData.filter { $0.distance == status[statusIndex] }
    } // var statusPicked: [Request] {}

    
    var body: some View {
        
      NavigationView {
         List {
            Picker(selection : $statusIndex ,
                   label : Text("Text")) {
                     
                     ForEach(0..<status.count) { index in
                        Text(self.status[index]).tag(index)
                     } // ForEach({ {}
                     
            } // Picker(selection) {}
               .pickerStyle(SegmentedPickerStyle())
               .padding(.bottom , 5)
            
            
            ForEach(statusPicked) { foodOffer in
               NavigationLink(destination : CherrypickerOfferDetailView(
                foodOffer : foodOffer, indexArray: foodOffersSampleData.firstIndex(where: {$0 === foodOffer}) ?? 0)) {
                     
                     CherrytreeFoodOfferNavigationLink(foodOffer : foodOffer)
                     
               } // NavigationLink(destination:) {}
            } // ForEach() {}
               .onDelete(perform : removeFoodOfferRows)
            
            
         } // List() {}
         //   .id(UUID())
            .navigationBarTitle(Text("Offers"))
      } // NavigationView {}
            .accentColor(CustomColor.cherrypickerRedLight.rgbColorValues)
        
        
        
    } // var body: some View {}
   
   
    // //////////////
   //  MARK: METHODS
   
   func removeFoodOfferRows(at offsets: IndexSet) {
      /* Because our ForEach was created entirely from a single array ,
       * we can actually just pass that index set
       * straight to our numbers array
       * – it has a special remove(atOffsets:) method
       * that accepts an index set :
       */
      foodOffersSampleData.remove(atOffsets : offsets)
   } // func removeRows(at offsets:) {}
   
   
   
    // /////////////////////////
   //  MARK: INITIALZER METHODS
   
   init() {
      
      UITableView.appearance().separatorStyle = .none
      UITableView.appearance().backgroundColor = .clear
      UITableViewCell.appearance().backgroundColor = .clear
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues]
      
      UISegmentedControl
         .appearance()
         .selectedSegmentTintColor = CustomUIColor.cherrypickerRedUI.rgbUIColorValues
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : UIColor.white] ,
                                 for : .selected)
      
      UISegmentedControl
         .appearance()
         .setTitleTextAttributes([.foregroundColor : CustomUIColor.cherrypickerRedDarkUI.rgbUIColorValues] ,
                                 for : .normal)
   } // init() {}
   
   
   
   
} // struct CherrypickerOffersTabView: View {}





// ///////////////
//  MARK: PREVIEWS

struct CherrypickerOffersTabView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        CherrypickerOffersTabView()
        
        
        
    } // static var previews: some View {}
} // struct CherrypickerOffersTabView_Previews: PreviewProvider {}
