//
//  CherrypickerOfferDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 09/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerOfferDetailView: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var foodOffer: FoodOffer
   @State private var showingAlert = false
    
    var indexArray: Int
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
 
      List {
         VStack(alignment : .center) {
            
            DetailViewImageFrame(accentColor : CustomColor.cherrypickerRedLight.rgbColorValues ,
                                 iconImageColor : CustomColor.cherrypickerRed.rgbColorValues ,
                                 foodOffer : foodOffer)
               .frame(width : 320 ,
                      height : 320 ,
                      alignment : .center)
               .padding(.top)
  
            
            VStack(alignment : .leading) {
               
               FoodOfferDescription(accentColor : CustomColor.cherrypickerRedLight.rgbColorValues ,
                                    offer : foodOffer ,
                                    titleColor : CustomColor.cherrypickerRed.rgbColorValues)
                  .padding(.bottom , 20)
               
               PickupTimeTable(accentColor : CustomColor.cherrypickerRed.rgbColorValues)
                  .padding(.bottom , 20)
               
               CompanyAddress(accentColor : CustomColor.cherrypickerRed.rgbColorValues)
               
            } // VStack(alignment: .leading) { {}
         } // VStack(alignment: .center) { {}
            .padding(.horizontal , 8)
      } // List {}
         .navigationBarTitle(Text(foodOffer.shopName) ,
                             displayMode : .inline)
         .navigationBarItems(trailing : Button(action : {
            print("The Add offer button has been tapped .")
            self.showingAlert = true
            print("UBHJNHUY \(self.indexArray)")
         }) {
            Image(systemName: "checkmark.circle")
               .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
               .font(Font.system(size : 27 ,
                                 weight : .medium))
         }) // .navigationBarItems(trailing:) {}
    .alert(isPresented: $showingAlert) {
        Alert(title: Text("Request sent"), message: Text("You successfully sent a request to this offer !"), dismissButton: .default(Text("Got it!")) {
            let newRequest = FoodRequest(name: "Name", status: .pending, date: "17 June", statusString: "Pending", offer: self.foodOffer)
            foodRequestsSampleData.append(newRequest)
            foodOffersSampleData.remove(at: self.indexArray)
                self.presentationMode.wrappedValue.dismiss()
            })
    }
      
      
      
   } // var body: some View {}
} // struct CherrypickerOfferDetailView: View {

 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerOfferDetailView_Previews: PreviewProvider {
   
   static var previews: some View {

      Group {
         CherrypickerOfferDetailView(foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                           number : 100 ,
                                                           info : "Info example" ,
                                                           pickupTime : "Monday morning" ,
                                                           dateCreated : "2 September" ,
                                                           creationDateCategory : "Today" ,
                                                           distance: "2 km",
                                                           shopName : "Carmina Food"), indexArray: 0)
            .previewDevice(PreviewDevice(rawValue : "iPhone XS Max"))
            .previewDisplayName("iPhone XS Max")
         
         CherrypickerOfferDetailView(foodOffer : FoodOffer(nameOfferer : "Davide" ,
                                                           number : 100 ,
                                                           info : "Info example" ,
                                                           pickupTime : "Monday morning" ,
                                                           dateCreated : "2 September" ,
                                                           creationDateCategory : "Today" ,
                                                           distance : "2 km",
                                                           shopName : "Carmina Food"), indexArray: 0)
            .previewDevice(PreviewDevice(rawValue : "iPhone 8"))
            .previewDisplayName("iPhone 8")
      } // Group {}
   } // static var previews: some View {}
} // struct CherrypickerOfferDetailView_Previews: PreviewProvider {}
