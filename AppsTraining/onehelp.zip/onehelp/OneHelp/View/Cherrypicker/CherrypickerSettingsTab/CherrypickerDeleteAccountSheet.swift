//
//  CherrypickerProfileAboutUsDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerDeleteAccountSheet: View {
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var reasonsForLeavingTheApp: String = ""
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack {
         VStack(alignment : .leading) {
            
            Text("Before you go, could you tell us what makes you want to leave?")
               .foregroundColor(CustomColor.blackCherry.rgbColorValues)
                     
               + Text(" I no longer want to make use of the Cherries app because \(reasonsForLeavingTheApp).")
            
            
            Spacer()
            
         } // VStack {}
            .lineSpacing(2.0)
            .foregroundColor(Color.red)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold))
            .padding()
            .frame(width : 320.0 ,
                   height : 350.0 ,
                   alignment : .leading)
            .background(
               RoundedRectangle(cornerRadius : 12.0)
                  .fill(Color.clear))
            .overlay(RoundedRectangle(cornerRadius : 15.0)
               .stroke(style : StrokeStyle(lineWidth : 6.0))
               .foregroundColor(Color.red))
            .padding(.top , 15)
            .padding(.bottom , 30)
            
            
            
            /* Your reason for leaving :
             */
            
            ZStack(alignment : .leading) {
               if reasonsForLeavingTheApp.isEmpty {
                  HStack {
                     Spacer()
                     Text("Your reason/s for leaving".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                     Spacer()
                  } // HStack {}
                     .foregroundColor(Color.secondary)
               } // if foodAllergy.isEmpty {}
               
               TextField("" , text : $reasonsForLeavingTheApp)
                  .multilineTextAlignment(.center)
                  .disableAutocorrection(true)
                  .foregroundColor(Color.red)
                  .padding(.vertical , 15)
                  .padding(.horizontal)
            } // ZStack {}
               .overlay(
                  RoundedRectangle(cornerRadius : 8)
                     .stroke(Color.secondary ,
                             lineWidth: 1))
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold))
               .frame(width : 320.0)
         
         
         
         
         Spacer()
         
         Button(action: {
            print("The Destroy Account Button is tapped .")
         }) {
            Text("Delete Account")
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold))
               .underline()
               .foregroundColor(Color.red)
               .padding()
         } // Button(action: ) {}
            .padding(.bottom)
         
         Text("Destroying your account erases all your data, including your profile data and social id data. You will need to create a new account and re-enter your personal details in order to be able to collect food.")
            
         + Text(" Please revert to our FAQ should you have any further questions.")
            .foregroundColor(CustomColor.blackCherry.rgbColorValues)
      }
      .lineSpacing(5.0)
      .font(Font.system(size: 16.0 ,
                        weight: .semibold,
                        design: .rounded))
         .foregroundColor(Color.red)
         .padding()
      
      
      
   } // var body: some View {}
} // struct CherrypickerProfileAboutUsDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerProfileAboutUsDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerDeleteAccountSheet()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerProfileAboutUsDetailView_Previews: PreviewProvider {}
