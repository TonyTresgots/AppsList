//
//  CherrypickerProfileIntroDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerUserProfilePage: View {
   
   // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State private var pseudonym: String = "George"
   @State private var numberOfHouseholdMembers: Int = 2
   @State private var foodAllergies: [String] = []
   @State private var foodAllergy: String = ""
   @State private var hasFoodAllergies: Bool = false
   @State private var isFemale: Bool = false
   @State private var isShowingDeleteAccountSheet: Bool = false
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      VStack(spacing : 30) {
         VStack(alignment : .leading) {
            
            Text("Your intro text to the food providers :")
               .foregroundColor(CustomColor.blackCherry.rgbColorValues)
               
               + Text(" \(pseudonym) lives in a household with \(numberOfHouseholdMembers == 1 ? "\(numberOfHouseholdMembers) dependant." : "\(numberOfHouseholdMembers) dependants.")")
               
               + Text(hasFoodAllergies == false ? " There are no known food allergies." : " There is a known food allergy. The food allergy is \(foodAllergy).")
            
            
            Spacer()
            
         } // VStack {}
            .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
            .font(Font.system(size : 21.0 ,
                              weight : .semibold))
            .padding()
            .frame(width : 320.0 ,
                   height : 250.0 ,
                   alignment : .leading)
            .background(
               RoundedRectangle(cornerRadius : 12.0)
                  .fill(Color.clear))
            .overlay(RoundedRectangle(cornerRadius : 15.0)
               .stroke(style : StrokeStyle(lineWidth : 6.0))
               .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues))
            .padding(.top , 15)
         
         
         
         /* Your name or pseudonym :
          */
         
         ZStack(alignment : .leading) {
            if pseudonym.isEmpty {
               HStack {
                  Spacer()
                  Text("Your name or pseudonym".uppercased())
                     .font(Font.system(size : 13.0 ,
                                       weight : .regular))
                  Spacer()
               } // HStack {}
                  .foregroundColor(Color.secondary)
            } // if foodAllergy.isEmpty {}
            
            TextField("" , text : $pseudonym)
               .multilineTextAlignment(.center)
               .disableAutocorrection(true)
               .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
               .padding(.vertical , 15)
               .padding(.horizontal)
         } // ZStack {}
            .overlay(
               RoundedRectangle(cornerRadius : 8)
                  .stroke(Color.secondary ,
                          lineWidth: 1))
            .font(Font.system(size : 21.0 ,
                              weight : .semibold))
            .frame(width : 320.0)
         
         
         
         /* Your household :
          */
         
         HStack {
            Image(systemName : "person.3.fill")
               .resizable()
               .scaledToFit()
               .frame(width : 55.0 ,
                      height : 21.0 ,
                      alignment: .center)
            Text("household size".uppercased())
               .font(Font.system(size : 13.0 ,
                                 weight : .regular))
               .foregroundColor(Color.secondary)
            Spacer()
            
            Stepper("" , value: $numberOfHouseholdMembers)
         } // HStack {}
            .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
            .frame(width : 320.0)
         
         
         
         /* Your food allergies :
          */
         
         Toggle(isOn: $hasFoodAllergies) {
            HStack {
               Image(systemName : "xmark.shield.fill")
                  .resizable()
                  .scaledToFit()
                  .frame(width : 55.0 ,
                         height : 21.0 ,
                         alignment : .center)
               Text("food allergy".uppercased())
                  .font(Font.system(size : 13.0 ,
                                    weight : .regular))
                  .foregroundColor(Color.secondary)
               Spacer()
            } // HStack {}
               .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
         } // Toggle(isOn: $hasFoodAllergies) {}
            .frame(width : 320.0)
         
         
         if hasFoodAllergies {
            
            ZStack(alignment : .leading) {
               if foodAllergy.isEmpty {
                  HStack {
                     Spacer()
                     Text("Your food allergies".uppercased())
                        .font(Font.system(size : 13.0 ,
                                          weight : .regular))
                     Spacer()
                  } // HStack {}
                     .foregroundColor(Color.secondary)
               } // if foodAllergy.isEmpty {}
               
               TextField("" , text : $foodAllergy)
                  .multilineTextAlignment(.center)
                  //                     .disableAutocorrection(true)
                  .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
                  .padding(.vertical , 15)
                  //                     .padding(.horizontal , 27)
                  .frame(width : 320.0)
            } // ZStack {}
               .overlay(
                  RoundedRectangle(cornerRadius : 8)
                     .stroke(Color.secondary ,
                             lineWidth: 1))
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold))
               //                  .padding(.horizontal , 27)
               .frame(width : 320.0)
            
         } // if hasFoodAllergies {}
         
         
         Spacer()
         
         Divider()
            .background(CustomColor.blackCherry.rgbColorValues)
            .padding(.horizontal)
         
         Button(action : {
            self.isShowingDeleteAccountSheet.toggle()
         }) {
            Text("Delete Account")
               .font(Font.system(size: 21.0 ,
                                 weight: .semibold))
               .foregroundColor(Color.red)
         } // Button(action:) {}
            .sheet(isPresented : $isShowingDeleteAccountSheet) {
               CherrypickerDeleteAccountSheet()
         } // .sheet(isPresented:) {}
            .padding(.bottom , 30)
      } // VStack(alignment : .leading) {}
         .padding(.top , 15)
         .navigationBarTitle(Text("User Profile") ,
                             displayMode : .inline)
         
         .navigationBarItems(
            trailing : Button(action: {
               print("The Save button is tapped .")
            }) {
               Image(systemName: "checkmark.circle")
                  .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                  .font(Font.system(size : 27 ,
                                    weight : .medium))
         }) // .navigationBarItems() {}
      
      
      
      
      
   } // var body: some View {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues]
      
   } // init() {}
} // struct CherrypickerProfileIntroDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerProfileIntroDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerUserProfilePage()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerProfileIntroDetailView_Previews: PreviewProvider {}
