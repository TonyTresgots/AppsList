//
//  CherrypickerProfileView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerSettingsTabView: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         ZStack(alignment : .topLeading) {
            GeometryReader { geometryProxy in
               Image("cherriesAppIconWhite1024")
                  .resizable()
                  .scaledToFit()
                  .frame(width: geometryProxy.size.width)
                  .position(x : geometryProxy.size.width/2  ,
                            y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
               
            } // GeometryReader { geometryProxy in }
            
            
            VStack(alignment : .leading , spacing: 18.0) {
               NavigationLink(destination : CherrypickerUserProfilePage()) {
                  HStack {
                     Text("User Profile")
                     Spacer()
                  } // HStack {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
               
               NavigationLink(destination: CherrypickerYourIDPage()) {
                  HStack {
                     Text("Your ID")
                     Spacer()
                  } // HStack {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
               
               NavigationLink(destination: CherrypickerFAQPage()) {
                  HStack {
                     Text("FAQ")
                     Spacer()
                  } // HSatck {}
               } // NavigationLink(destination:) {}
               
               Divider()
                  .background(CustomColor.blackCherry.rgbColorValues)
            } // VStack {}
               .padding()
               .font(Font.system(size : 21.0 ,
                                 weight : .semibold ,
                                 design : .rounded))
               .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
         } // NavigationView {}
            .navigationBarTitle(Text("Settings"))
         
      } // NavigationView {}
         .accentColor(CustomColor.cherrypickerRed.rgbColorValues)
   } // var body: some View {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      UITabBar.appearance().barTintColor = UIColor.white
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues]
   } // init() {}
   
   
   
} // struct CherrypickerSettingsTabView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerSettingsTabView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerSettingsTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerSettingsTabView_Previews: PreviewProvider {}
