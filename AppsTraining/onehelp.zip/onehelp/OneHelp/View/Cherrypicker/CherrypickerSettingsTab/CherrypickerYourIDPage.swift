//
//  CherrypickerProfileWelcomeDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 08/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerYourIDPage: View {
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      Group {
         Text("ID Settings")
            .font(Font.system(size: 21.0 ,
                              weight: .semibold,
                              design: .rounded))
            .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
            .padding()
      } // .navigationBarItems(trailing:) {}
         .navigationBarTitle(Text("Your ID") ,
                             displayMode : .inline)
         .accentColor(CustomColor.cherrypickerRed.rgbColorValues)
      
      
      
   } // var body: some View {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = UIColor.white
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : CustomUIColor.cherrypickerRedLightUI.rgbUIColorValues]
      
   } // init() {}
   
   
   
} // struct CherrypickerProfileWelcomeDetailView: View {}





 // ///////////////
//  MARK: PREVIEWS

struct CherrypickerProfileWelcomeDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrypickerYourIDPage()
      
      
      
   } // static var previews: some View {}
} // struct CherrypickerProfileWelcomeDetailView_Previews: PreviewProvider {}
