//
//  CherrytreeOfferDetailView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeRequestDetailView: View {
   
   // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var textColor: Color = CustomColor.backgroundRed.rgbValues
   
   
   
   // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @State var cherrytree: Cherrytree
   @State var foodOffer: FoodOffer
   
   
   
   // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      ZStack {
         Rectangle()
            .edgesIgnoringSafeArea(.all)
            .applyBackgroundGradient(accentColor : backGroundColor.opacity(0.55))
         
         
         ScrollView {
            VStack(alignment : .center) {
               
               DetailViewImageFrame(foodOffer : foodOffer)
                  .frame(width : 320 ,
                         height : 320 ,
                         alignment : .center)
                  .padding(.top , 30)
               
               
               
               VStack(alignment : .leading) {
                  
                  Text("Offer number 1".uppercased())
                     .fontWeight(.bold)
                     .font(.caption)
                     .foregroundColor(textColor)
                     .padding(.vertical , 10)
                  
                  
                  Text("The offer includes a box for 2 people with 2 packets of pasta , 2 bottles of tomato sauce , 2 cans of beans , and 1 pack of rice .")
                     .font(Font.system(size : 21.0 ,
                                       weight : .semibold))
                     .foregroundColor(textColor)
                     .padding(.bottom , 20)
                  
                  
                  Text("pickup time".uppercased())
                     .fontWeight(.bold)
                     .font(.caption)
                     .foregroundColor(self.textColor)
                     .padding(.bottom , 10)
                  
                  
                  VStack(alignment : .leading) {
                     
                     VStack(alignment : .leading , spacing : 5) {
                        HStack(alignment : .center) {
                           Text("Monday")
                              .foregroundColor(Color.secondary)
                              .font(Font.system(size : 15.0 ,
                                                weight : .light))
                           Spacer()
                           Text("14:00 - 17:00")
                              .foregroundColor(textColor)
                              .fontWeight(.medium)
                        } // HStack {}
                        
                        
                        HStack(alignment: .center) {
                           Text("Tuesday - Friday")
                              .foregroundColor(Color.secondary)
                              .font(Font.system(size : 15.0 ,
                                                weight : .light))
                           Spacer()
                           Text("16:00 - 19:00")
                              .foregroundColor(self.textColor)
                              .fontWeight(.medium)
                        } // HStack {}
                        
                        
                        HStack(alignment: .center) {
                           Text("Saturday")
                              .foregroundColor(Color.secondary)
                              .font(Font.system(size : 15.0 ,
                                                weight : .light))
                           Spacer()
                           Text("09:00 - 11:00")
                              .foregroundColor(textColor)
                              .fontWeight(.medium)
                        } // HStack {}
                        
                        
                        HStack(alignment: .center) {
                           Text("Sunday")
                              .foregroundColor(Color.secondary)
                              .font(Font.system(size : 15.0 ,
                                                weight : .light))
                           Spacer()
                           Text("No Food Pickup".uppercased())
                              .foregroundColor(textColor)
                              .font(Font.system(size : 13.0 ,
                                                weight : .medium))
                        } // HStack {}
                     } // VStack {}
                        .foregroundColor(Color.gray)
                        .font(.subheadline)
                  } // VStack(alignment: , spacing:) {}
                     .padding(.bottom , 20)
                  
                  
                  Text("address".uppercased())
                     .fontWeight(.bold)
                     .font(.caption)
                     .foregroundColor(self.textColor)
                     .padding(.bottom , 10)
                  
                  
                  VStack(alignment : .leading , spacing : 5) {
                     Text("Via Rue Moliere 12 a bis")
                     Text("Napoli 80121")
                     Text("Italy")
                     
                     HStack {
                        Image(systemName: "phone.fill")
                        Text("0123456789")
                     } // HStack
                  } // VStack(alignment : .leading) {}
                     .font(Font.system(size : 15.0 ,
                                       weight : .regular))
                     .foregroundColor(Color.secondary)
                  
                  
               } // VStack(alignment: .leading) { {}
               
               
               
               
            } // VStack(alignment: .center) { {}
               .padding(.horizontal , 30)
         } // ScrollView(alignment:) {}
      } // ZStack {}
         .navigationBarTitle(Text("Carmina Food") ,
                             displayMode : .inline)
         .navigationBarItems(trailing : Button(action : {
            print("The Reject offer button has been tapped .")
         }) {
            Image(systemName: "trash.circle")
               .font(.title)
               .foregroundColor(textColor)
         })
      
      
      
   } // var body: some View {}
} // struct CherrytreeOfferDetailView: View {}





// ///////////////
//  MARK: PREVIEWS

struct CherrytreeOfferDetailView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      
      Group {
         CherrytreeRequestDetailView(cherrytree : Cherrytree() ,
                                       foodOffer : FoodOffer(number : 333))
            .previewDevice(PreviewDevice(rawValue : "iPhone XS Max"))
            .previewDisplayName("iPhone XS Max")
         
         CherrytreeRequestDetailView(cherrytree : Cherrytree() ,
                                       foodOffer : FoodOffer(number : 333))
            .previewDevice(PreviewDevice(rawValue : "iPhone 8"))
            .previewDisplayName("iPhone 8")
      } // Group {}
      
      
   } // static var previews: some View {}
} // struct CherrytreeOfferDetailView_Previews: PreviewProvider {}
