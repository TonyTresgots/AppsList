//
//  CherrytreeOffersView.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 04/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI

struct CherrytreeRequestsTabView: View {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var backGroundColor: Color = CustomColor.backgroundDeepPink.rgbValues
   var textColor: Color = CustomColor.backgroundRed.rgbValues
   
   var barTextColorPink: UIColor = UIColor(red : 186.0/255.0 ,
                                           green : 0.0/255.0 ,
                                           blue : 32.0/255.0 ,
                                           alpha : 1)
   
   var barTintColorPink: UIColor  = UIColor(red : 254.0/255.0 ,
                                            green : 213.0/255.0 ,
                                            blue : 232.0/255.0 ,
                                            alpha : 1)
   
   
   
    // ////////////////////////
   //  MARK: PROPERTY WRAPPERS
   
   @ObservedObject var cherrytree: Cherrytree = Cherrytree()

   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         
//         Rectangle()
//            .edgesIgnoringSafeArea(.all)
//            .applyBackgroundGradient(accentColor: backGroundColor.opacity(0.55))
         
         List {
            CherrytreeSegmentedControl()
            
            
            ForEach(self.cherrytree.foodOffers) { foodOffer in
               NavigationLink(destination : CherrytreeFoodOfferDetailView(cherrytree : self.cherrytree ,
                                                                          foodOffer : foodOffer)) {
                  
                  CherrytreeFoodOfferNavigationLink(foodOffer : foodOffer)
                  
               } // NavigationLink(destination:) {}
            } // ForEach() {}
               .onDelete(perform : removeFoodOfferRows)
            
            
         } // List() {}
            .navigationBarItems(trailing : EditButton())
            .navigationBarTitle(Text("Requests"))
            .onAppear {
               UITableView.appearance().separatorStyle = .none
               UITableView.appearance().backgroundColor = .clear
               UITableViewCell.appearance().backgroundColor = .clear
         } // .onAppear {}
         
      } // NavigationView {}
            .accentColor(textColor)
      
      
      
   } // var body: some View {}
   
   
   
    // //////////////
   //  MARK: METHODS
   
   func removeFoodOfferRows(at offsets: IndexSet) {
      /* Because our ForEach was created entirely from a single array ,
       * we can actually just pass that index set
       * straight to our numbers array
       * – it has a special remove(atOffsets:) method
       * that accepts an index set :
       */
      cherrytree.foodOffers.remove(atOffsets : offsets)
   } // func removeRows(at offsets:) {}
   
   
   
    // ////////////////////
   //  INITIALIZER METHODS
   
   init() {
      
      // Colors the large navigation bar title :
      
      UINavigationBar
         .appearance()
         .largeTitleTextAttributes = [
            .foregroundColor : barTextColorPink ,
            .font : UIFont(name : "ArialRoundedMTBold" ,
                           size : 40)!
      ] // .largeTitleTextAttributes = []
      
      // Colors the navigation bar when scrolling up :
      
      UINavigationBar
         .appearance()
         .barTintColor = barTintColorPink
      
      // Colors the inline display style title :
      
      UINavigationBar
         .appearance()
         .titleTextAttributes = [.foregroundColor : barTextColorPink]
      
   } // init() {}
   

   
} // struct CherrytreeOffersView: View {}




 // ///////////////
//  MARK: PREVIEWS

struct CherrytreeOffersView_Previews: PreviewProvider {
   
   static var previews: some View {
      
      CherrytreeRequestsTabView()
      
      
      
   } // static var previews: some View {}
} // struct CherrytreeOffersView_Previews: PreviewProvider {}
