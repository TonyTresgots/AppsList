//
//  WelcomeScreen.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct WelcomeScreen: View {
    
    @EnvironmentObject var appState: AppState
   
   
   
    // ///////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var body: some View {
      
      NavigationView {
         ZStack(alignment : .topLeading) {
            CustomColor.cherryBlossomSoftPink.rgbColorValues
               .edgesIgnoringSafeArea(.all)
            
            
            VStack(alignment: .leading) {
               Text("Cherries.")
                  .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
               Text("For those in need.")
                  .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
            } // VStack(alignment:) {}
            .font(Font.system(size : 40 ,
                              weight : .semibold ,
                              design : .rounded))
            .padding()
            
            
            GeometryReader { geometryProxy in
               ZStack {
                  Image("cherriesAppIconPink1024")
                     .resizable()
                     .scaledToFit()
                     .frame(width: geometryProxy.size.width)
                     .position(x : geometryProxy.size.width/2  ,
                               y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
               } // ZStack {}
               
               
               VStack(spacing: 25) {
                  NavigationLink(destination : CherrytreeIntro()) {
                     
                     Text("Donate Food")
                        .font(Font.system(size : 21.0 ,
                                          weight : .semibold))
                        .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                        .frame(width: geometryProxy.size.width / 1.3 ,
                               height : geometryProxy.size.height / 10)
                        .background(
                           RoundedRectangle(cornerRadius: .infinity)
                              .foregroundColor(CustomColor.cherryBlossomDark.rgbColorValues))
                  } // NavigationLink(destination:) {}
                  
                  
                  NavigationLink(destination : CherrypickerIntro()) {
                     
                     Text("Collect Food")
                        .font(Font.system(size : 21.0 ,
                                          weight : .semibold))
                        .foregroundColor(CustomColor.cherrypickerRedDark.rgbColorValues)
                        .frame(width : geometryProxy.size.width / 1.3,
                               height : geometryProxy.size.height / 10)
                        .background(
                           RoundedRectangle(cornerRadius : .infinity)
                              .foregroundColor(CustomColor.cherryBlossomDark.rgbColorValues))
                  } // NavigationLink(destination:) {}
               } // VStack(alignment: {}) {}
                  .position(x : geometryProxy.size.width / 2  ,
                            y : geometryProxy.size.height - geometryProxy.size.width / 0.85)
       
            } // GeometryReader { geometryProxy in }
         } // ZStack {}
         .navigationBarTitle(Text(""))
         .navigationBarHidden(true)
         
         
      } // NavigationView {}
   } // var body: some View {}
} // struct WelcomeScreen: View {}





 // ///////////////
//  MARK: PREVIEWS

struct WelcomeScreen_Previews: PreviewProvider {
   
   static var previews: some View {
      
      WelcomeScreen()
      
      
      
   } // static var previews: some View {}
} // struct WelcomeScreen_Previews: PreviewProvider {}
