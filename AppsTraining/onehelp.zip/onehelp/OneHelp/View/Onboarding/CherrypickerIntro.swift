//
//  CherrypickerIntro.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrypickerIntro: View {
    
    @EnvironmentObject var appState: AppState
    
   
   
    // ///////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var body: some View {
        
        NavigationView {
            ZStack(alignment : .topLeading) {
                CustomColor.cherryBlossomSoftPink.rgbColorValues
                    .edgesIgnoringSafeArea(.all)
                
                
                VStack(alignment: .leading) {
                    Text("Cherrypicker.")
                        .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
                    Text("Food Recipient.")
                        .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                } // VStack(alignment:) {}
                    .font(Font.system(size : 40 ,
                                      weight : .semibold ,
                                      design : .rounded))
                    .padding()
                
                
                Text("Request food offers,\narrange a pickup time,\nand collect donated food from shops.")
                    .lineSpacing(4)
                    .padding()
                    .padding(.top ,
                             110)
                    .font(Font.system(size : 21.0 ,
                                      weight : .medium))
                    .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                
                
                
                GeometryReader { geometryProxy in
                    ZStack {
                        Image("cherriesAppIconPink1024")
                            .resizable()
                            .scaledToFit()
                            .frame(width : geometryProxy.size.width)
                            .position(x : geometryProxy.size.width / 2  ,
                                      y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
                    } // ZStack {}
                    
                    Button(action: {
                        self.appState.reloadDashboard()
                     print("self.appState.realoadDashboard2()")
                    }) {
                        Text("Start Collecting Food")
                            .font(Font.system(size : 21.0 ,
                                              weight : .semibold))
                            .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                            .frame(width : geometryProxy.size.width / 1.3,
                                   height : geometryProxy.size.height / 10)
                            .background(
                                RoundedRectangle(cornerRadius : .infinity)
                                    .foregroundColor(CustomColor.cherryBlossomDark.rgbColorValues))
                    }.position(x : geometryProxy.size.width / 2  ,
                            y : geometryProxy.size.height - geometryProxy.size.width / 0.95)

                } // GeometryReader { geometryProxy in }
                
            } // ZStack {}
                .navigationBarTitle(Text(""))
                .navigationBarHidden(true)
            
            
        } // NavigationView {}
    } // var body: some View {}
} // struct CherrypickerIntro: View {}





// ///////////////
//  MARK: PREVIEWS

struct CherrypickerIntro_Previews: PreviewProvider {
    
    static var previews: some View {
        
        CherrypickerIntro()
        
        
        
    } // static var previews: some View {}
} // struct CherrypickerIntro_Previews: PreviewProvider {}
