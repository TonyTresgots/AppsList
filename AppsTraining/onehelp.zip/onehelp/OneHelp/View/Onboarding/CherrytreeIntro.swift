//
//  CherrytreeIntro.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 11/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct CherrytreeIntro: View {
    
    // /////////////////
    //  MARK: PROPERTIES
    
    @EnvironmentObject var appState: AppState
    
    var backGroundRed: Color = CustomColor.cherryRed.rgbColorValues
    var backGroundGreen: Color = CustomColor.backgroundGreen.rgbColorValues
    var redTextColor: Color = CustomColor.backgroundRed.rgbColorValues
    var greenTextColor: Color = CustomColor.headerGreen.rgbColorValues
    
    
    
    // ///////////////////////////
    //  MARK: COMPUTED PROPERTIES
    
    var body: some View {
        
        NavigationView {
            ZStack(alignment : .topLeading) {
                CustomColor.cherryBlossomSoftPink.rgbColorValues
                    .edgesIgnoringSafeArea(.all)
                
                
                VStack(alignment: .leading) {
                    Text("Cherrytree.")
                        .foregroundColor(CustomColor.cherrypickerRedLight.rgbColorValues)
                    Text("Food Donator.")
                        .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                } // VStack(alignment:) {}
                    .font(Font.system(size : 40 ,
                                      weight : .semibold,
                                      design : .rounded))
                    .padding()
                
                
                Text("Clear your shop inventory of nearly expired food and donate it to those that need it most. Your actions could contribute to less food waste and more social equality.")
                    .lineSpacing(4.0)
                    .padding()
                    .padding(.top , 110)
                    .font(Font.system(size : 21.0 ,
                                      weight : .medium))
                    .foregroundColor(self.redTextColor)
                
                
                
                GeometryReader { geometryProxy in
                    ZStack {
                        Image("cherriesAppIconPink1024")
                            .resizable()
                            .scaledToFit()
                            .frame(width : geometryProxy.size.width)
                            .position(x : geometryProxy.size.width / 2  ,
                                      y : geometryProxy.size.height - geometryProxy.size.width / 2.5)
                    } // ZStack {}
                    
                    Button(action: {
                        self.appState.realoadDashboard2()
                     print("self.appState.realoadDashboard2()")
                    }) {
                        Text("Start Donating Food")
                            .font(Font.system(size : 21.0 ,
                                              weight : .semibold))
                            .foregroundColor(CustomColor.cherrypickerRed.rgbColorValues)
                            .frame(width : geometryProxy.size.width / 1.3,
                                   height : geometryProxy.size.height / 10)
                            .background(
                                RoundedRectangle(cornerRadius: .infinity)
                                    .foregroundColor(CustomColor.cherryBlossomDark.rgbColorValues))
                    }.position(x : geometryProxy.size.width / 2  ,
                                y : geometryProxy.size.height - geometryProxy.size.width / 0.95)

                } // GeometryReader { geometryProxy in }
                
            } // ZStack {}
                .navigationBarTitle(Text(""))
                .navigationBarHidden(true)
            
            
        } // NavigationView {}
    } // var body: some View {}
} // struct CherrytreeIntro: View {}





// ///////////////
//  MARK: PREVIEWS

struct CherrytreeIntro_Previews: PreviewProvider {
    
    static var previews: some View {
        
        CherrytreeIntro()
        
        
        
    } // static var previews: some View {}
} // struct CherrytreeIntro_Previews: PreviewProvider {}
