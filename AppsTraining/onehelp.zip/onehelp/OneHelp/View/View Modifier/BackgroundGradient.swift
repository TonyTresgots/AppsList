//
//  PinkBackgroundGradient.swift
//  OneHelp
//
//  Created by Olivier Van hamme on 30/05/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import SwiftUI


struct BackgroundGradient: ViewModifier {
   
    // /////////////////
   //  MARK: PROPERTIES
   
   var accentColor: Color
   
   
   
    // //////////////////////////
   //  MARK: COMPUTED PROPERTIES
   
   var gradient: Gradient {
      let colorStops: [Gradient.Stop] = [
         .init(color : Color.white ,
               location : 0.30) ,
         .init(color : accentColor ,
               location : 0.90)
      ] // let colorStops: [Gradient.Stop] = []
      
      return Gradient(stops : colorStops)
   } // var gradient: Gradient {}
   
   
   
    // //////////////
   //  MARK: METHODS
   
   func body(content: Content)
      -> some View {
         
         LinearGradient(gradient : gradient ,
                        startPoint : .center ,
                        endPoint : .top)
            .edgesIgnoringSafeArea(.all)
         
   } // var body: some View {}
} // struct PinkBackgroundGradient: View {}





 // /////////////////
//  MARK: EXTENSIONS

extension View {
   
   func applyBackgroundGradient(accentColor: Color)
      -> some View {
         
         self.modifier(BackgroundGradient(accentColor : accentColor))
         
   } // func applyBackgroundGradient() -> some View {}
   
} // extension View {}


