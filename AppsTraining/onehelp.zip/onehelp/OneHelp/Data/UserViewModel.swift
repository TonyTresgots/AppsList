//
//  UserViewModel.swift
//  OneHelp
//
//  Created by Tony Tresgots on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import Foundation
import SwiftUI
import Combine

class UsersListViewModel: ObservableObject {
    @Published
    var users = [UserViewModel]()
    
    init() {
        fetchAllUsers()
    }
    
    func fetchAllUsers() {
        self.users = CoreDataManager.shared.getAllUsers().map(UserViewModel.init)
    }
}

class UserViewModel {
    var pseudo = ""
    var famSize = 0
    var allergies = ""
    
    init(user: UserTest) {
        self.pseudo = user.pseudo!
        self.famSize = Int(user.famSize)
        self.allergies = "allergie example"
    }
}
