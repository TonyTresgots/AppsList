//
//  CoreDataManager.swift
//  OneHelp
//
//  Created by Tony Tresgots on 05/06/2020.
//  Copyright © 2020 Tony Tresgots. All rights reserved.
//

import Foundation
import CoreData


class CoreDataManager {
    static let shared = CoreDataManager(moc: NSManagedObjectContext.current)
    
    var moc : NSManagedObjectContext
    
    private init(moc: NSManagedObjectContext) {
        self.moc = moc
    }
    
    func getUser() {
        
    }
    
    func getAllOffers() {
        
    }
    
    func getAllUsers() -> [UserTest] {
        var users = [UserTest]()
        let userRequest: NSFetchRequest<UserTest> = UserTest.fetchRequest()
        
        do {
            users = try self.moc.fetch(userRequest)
        } catch let error {
            print("error \(error)")
        }
        
        return users
    }
}
