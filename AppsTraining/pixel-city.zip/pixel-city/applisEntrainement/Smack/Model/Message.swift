//
//  Message.swift
//  Smack
//
//  Created by Tony Tresgots on 24/01/2018.
//  Copyright © 2018 Tony Tresgots. All rights reserved.
//

import Foundation

struct Message {
    public private(set) var message : String!
    public private(set) var userName : String!
    public private(set) var userAvatar : String!
    public private(set) var userAvatarColor : String!      // les parametres de l'API necessaire pour parser ( PostMan )
    public private(set) var channelId : String!             // utilisés dans le configureCell pour parser
    public private(set) var id : String!
    public private(set) var timeStamp : String!

}
