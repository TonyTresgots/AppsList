//
//  Manager.swift
//  Smack
//
//  Created by Tony Tresgots on 23/01/2018.
//  Copyright © 2018 Tony Tresgots. All rights reserved.
//

import Foundation
import SocketIO

class Manager {
    
    var socketManager = SocketManager(socketURL: URL(string : BASE_URL)!)

    func addHandlers() {
        let socket = socketManager.socket(forNamespace: "/swift")
        
        // Add handlers
    }
}

