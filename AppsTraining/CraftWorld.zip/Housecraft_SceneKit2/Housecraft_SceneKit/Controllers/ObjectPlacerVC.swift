//
//  ObjectPlacerVC.swift
//  Housecraft_SceneKit
//
//  Created by Tony Tresgots on 05/12/2019.
//  Copyright © 2019 Tony Tresgots. All rights reserved.
//

import UIKit
import ARKit
import SceneKit

class ObjectPlacerVC: UIViewController, ARSCNViewDelegate, UIPopoverPresentationControllerDelegate, UIGestureRecognizerDelegate {
    
    var selectedObjectName : String?
    var selectedObject : SCNNode?
    
    var selectedNode : SCNNode?
    
    var planeNodes = [SCNNode]()
    
    let rocketshipNodeName = "rocketship"
    
    var PCoordx: Float = 0.0
    var PCoordy: Float = 0.0
    var PCoordz: Float = 0.0
    
    var isPinch = false
    
    //  var detectedPlanes: [String : SCNNode] = [:]
    
    @IBOutlet weak var sceneView: ARSCNView!
    @IBOutlet weak var objectName: UILabel!
    @IBOutlet weak var trashButton: UIButton!
    @IBOutlet weak var rotateButton: UIButton!
    
    @IBAction func showUpPopoverButton(_ sender: UIButton) {
        let objectPickerVC = ObjectPickerVC(size: CGSize(width: self.view.frame.width - 20, height: 500))
        objectPickerVC.objectPlacerVC = self    // send the rampPickerVC to the rampPlacerVC
        objectPickerVC.modalPresentationStyle = .popover
        objectPickerVC.popoverPresentationController?.delegate = self
        
        present(objectPickerVC, animated: true, completion: nil)
        objectPickerVC.popoverPresentationController?.sourceView = sender
        objectPickerVC.popoverPresentationController?.sourceRect = sender.bounds
    }
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        if selectedNode != nil {
            if !planeNodes.contains(selectedNode!) {
                removeAllObj()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        self.sceneView.delegate = self
        
        // Create a new scene   /   sinon pas de AR inside the camera
        let scene = SCNScene(named: "art.scnassets/main.scn")!
        
        // Set the scene to the view
        self.sceneView.scene = scene
        
        configureLighting()
        addSwipeGesturesToSceneView()
        
        let pinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(handlePitch(withGestureRecognizer:)))
        sceneView.addGestureRecognizer(pinchGestureRecognizer)
        
        let gesture1 = UILongPressGestureRecognizer(target: self, action: #selector(onLongPress(gesture:)))
        
        gesture1.minimumPressDuration = 0.5
        rotateButton.addGestureRecognizer(gesture1)
        
        let gesture2 = UILongPressGestureRecognizer(target: self, action: #selector(onLongPress2(gesture:)))
        
        gesture2.minimumPressDuration = 1
        trashButton.addGestureRecognizer(gesture2)
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none        // si on oublie cette func --> popover full screen
    }
    
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    func onObjectSelected(_ objectName : String) {
        selectedObjectName = objectName
    }
    
    
    // TODO: Create add swipe gestures to scene view method
    func addSwipeGesturesToSceneView() {

        let swipeUpGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(applyForceToRocketship(withGestureRecognizer:)))
        swipeUpGestureRecognizer.direction = .up
        sceneView.addGestureRecognizer(swipeUpGestureRecognizer)
        
        let swipeDownGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(launchRocketship(withGestureRecognizer:)))
        swipeDownGestureRecognizer.direction = .down
        sceneView.addGestureRecognizer(swipeDownGestureRecognizer)
    }
    
    @objc func onLongPress(gesture: UILongPressGestureRecognizer) {
        if let obj = selectedNode {    // si une ramp est selected
            if gesture.state == .ended {        // if rotateBtn no more pressed --> remove all actions ( no more rotation )
                if obj.parent?.name == "rocketship" {
                    obj.parent!.removeAllActions()
                } else {
                    obj.removeAllActions()
                }
            } else if gesture.state == .began {     // gesture.state --> pressed or not
                if gesture.view === rotateButton {     // if the view pressed is the rotateBtn
                    if obj.parent?.name == "rocketship" {
                        let rotate = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: CGFloat(0.08 * Double.pi), z: 0, duration: 0.1))
                        obj.parent!.runAction(rotate)
                    } else {
                        let rotate = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: CGFloat(0.08 * Double.pi), z: 0, duration: 0.1))
                        obj.runAction(rotate)      // when button rotateBtn pressed rotate forever until unpressed
                    }
                }
            }
        }
    }
    
    @objc func onLongPress2(gesture: UILongPressGestureRecognizer) {
        sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
            if node.name != nil {
                node.removeFromParentNode()
            }
        }
    }
    
    func getRocketshipNode(from swipeLocation: CGPoint) -> SCNNode? {
        let hitTestResults = sceneView.hitTest(swipeLocation)
        guard let parentNode = hitTestResults.first?.node.parent,
            parentNode.name == rocketshipNodeName
            else { return nil }
        return parentNode
    }
    
    // TODO: Create apply force to rocketship method
    @objc func applyForceToRocketship(withGestureRecognizer recognizer: UIGestureRecognizer) {
        // 1
        guard recognizer.state == .ended else { return }
        // 2
        let swipeLocation = recognizer.location(in: sceneView)
        // 3
        guard let rocketshipNode = getRocketshipNode(from: swipeLocation),
            let physicsBody = rocketshipNode.physicsBody
            else { return }
        
        // 4
        let direction = SCNVector3(0, 3, 0)
        physicsBody.applyForce(direction, asImpulse: true)
    }
    
    @objc func launchRocketship(withGestureRecognizer recognizer: UIGestureRecognizer) {
        // 1
        guard recognizer.state == .ended else { return }
        
        // 2
        let swipeLocation = recognizer.location(in: sceneView)
        guard let rocketshipNode = getRocketshipNode(from: swipeLocation),
            let physicsBody = rocketshipNode.physicsBody,
            let reactorParticleSystem = SCNParticleSystem(named: "art.scnassets/textures/reactor", inDirectory: nil),
            let engineNode = rocketshipNode.childNode(withName: "rocketnode2", recursively: false)
            else { return }
        // 3
        physicsBody.isAffectedByGravity = false
        physicsBody.damping = 0
        // 4
        reactorParticleSystem.colliderNodes = planeNodes
        //        // 5
        engineNode.addParticleSystem(reactorParticleSystem)
        // 6
        let action = SCNAction.moveBy(x: 0, y: 0.3, z: 0, duration: 3)
        action.timingMode = .easeInEaseOut
        rocketshipNode.runAction(action)
    }
    
    func placeObject(position: SCNVector3) {
        
        if let objectName = selectedObjectName {
            
            let object = ObjectModel.getObjectName(objectName: objectName)
            selectedObject = object
            selectedNode = object
            object.position = position        // position of the 3D object in the camera
            
            if objectName == "rocketship" || objectName == "submarine" {
                object.scale = SCNVector3Make(0.1, 0.1, 0.1)   // taille par defaut de l'objet
            } else {
                object.scale = SCNVector3Make(0.01, 0.01, 0.01)
            }
            
            let objectBodyPhysic = SCNPhysicsBody(type: .dynamic, shape: SCNPhysicsShape(node: object, options: nil))
            if objectName == "pyramid" || objectName == "pipe" || objectName == "quarter" || objectName == "rocketship" {
                objectBodyPhysic.mass = 2
                objectBodyPhysic.friction = 2
                objectBodyPhysic.allowsResting = true
                object.physicsBody = objectBodyPhysic
                object.physicsBody?.applyForce(SCNVector3(x: 1, y: 1, z:1), asImpulse: false)
            }
            sceneView.scene.rootNode.addChildNode(object)
            
            self.selectedObjectName = nil
            self.selectedObject = nil
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {  // detecte the touch to place the object / common process for ARKit
        
        guard let touch = touches.first else { return }     // grab the touch        
        
        let location: CGPoint = touch.location(in: touch.view)
        let hits = self.sceneView.hitTest(location, options: nil)
        if let tappedNode = hits.first?.node {
            if tappedNode.name != nil {
                if tappedNode.parent?.name == "rocketship" {
                    self.objectName.text = "ROCKETSHIP"
                    for child in (tappedNode.parent?.childNodes)! {
                        SCNTransaction.begin()
                        SCNTransaction.animationDuration = 0.5
                        
                        // on completion - unhighlight
                        SCNTransaction.completionBlock = {
                            SCNTransaction.begin()
                            SCNTransaction.animationDuration = 0.5
                            child.geometry?.firstMaterial?.emission.contents = UIColor.black
                            SCNTransaction.commit()
                        }
                        child.geometry?.firstMaterial?.emission.contents = UIColor.red
                        SCNTransaction.commit()
                    }
                    //                if selectedObjectName == nil || selectedObject == nil {
                    //                    if !isPinch {
                    //                        let tapGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handleDragGesture(_:)))
                    //                        sceneView.addGestureRecognizer(tapGestureRecognizer)
                    //                    }
                    //                }
                    selectedNode = tappedNode
                    return
                }
            
            
            
            let material = hits.first?.node.geometry!.firstMaterial!
            
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material?.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material?.emission.contents = UIColor.red
            
            SCNTransaction.commit()
            
            if selectedObjectName == nil || selectedObject == nil {
                if !isPinch {
                    let tapGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handleDragGesture(_:)))
                    sceneView.addGestureRecognizer(tapGestureRecognizer)
                }
            }
            selectedNode = tappedNode
                self.objectName.text = tappedNode.name?.uppercased()

            return
            }
        }
        
        let results = sceneView.hitTest(touch.location(in: sceneView), types: [.featurePoint])  // .featurePoint --> ARKit property ( detecte murs, sols etc )
        
        guard let hitFeature = results.last else { return } // releve les murs/sols, si jamais trop sombres/impossible de placer object --> return empty
        let hitTransform = SCNMatrix4(hitFeature.worldTransform)    // but if we got something --> transform it for AR to place 3D obj
        let hitPosition = SCNVector3Make(hitTransform.m41, hitTransform.m42, hitTransform.m43)
        if selectedObjectName != nil {
            placeObject(position: hitPosition)
        }
        
        let translation = hitFeature.worldTransform.translation
        let x = translation.x
        let y = translation.y + 0.1
        let z = translation.z
        
        guard let rocketshipScene = SCNScene(named: "rocketship.scn"),
            let rocketshipNode = rocketshipScene.rootNode.childNode(withName: "rocketship", recursively: false)
            else { return }
        
        rocketshipNode.position = SCNVector3(x,y,z)
        
        let physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        rocketshipNode.physicsBody = physicsBody
        rocketshipNode.name = rocketshipNodeName
        
        sceneView.scene.rootNode.addChildNode(rocketshipNode)
    }
    
    @objc func handlePitch(withGestureRecognizer recognizer: UIPinchGestureRecognizer) {
        
        let tapRecognizer = recognizer.location(in: sceneView)
        let hitTestResults = sceneView.hitTest(tapRecognizer)
        guard let node = hitTestResults.first?.node else {
            return
        }
        
        if node.name != nil {
            
            if node.parent?.name == "rocketship" {
                if (recognizer.state == .changed) {
                    isPinch = true
                    let pinchScaleX = Float(recognizer.scale) * node.parent!.scale.x
                    let pinchScaleY =  Float(recognizer.scale) * node.parent!.scale.y
                    let pinchScaleZ =  Float(recognizer.scale) * node.parent!.scale.z
                    
                    node.parent!.scale = SCNVector3(x: Float(pinchScaleX), y: Float(pinchScaleY), z: Float(pinchScaleZ))
                    recognizer.scale = 1
                }
                
            } else {
                if (recognizer.state == .changed) {
                    isPinch = true
                    let pinchScaleX = Float(recognizer.scale) * node.scale.x
                    let pinchScaleY =  Float(recognizer.scale) * node.scale.y
                    let pinchScaleZ =  Float(recognizer.scale) * node.scale.z
                    
                    node.scale = SCNVector3(x: Float(pinchScaleX), y: Float(pinchScaleY), z: Float(pinchScaleZ))
                    recognizer.scale = 1
                }
            }
        }
        
        if recognizer.state == .ended {
            isPinch = false
        }
        
    }
    
    @objc func handleDragGesture(_ sender: UIPanGestureRecognizer) {
        
        switch sender.state {
        case .began:
            let hitNode = self.sceneView.hitTest(sender.location(in: self.sceneView),
                                                 options: nil)
            if !hitNode.isEmpty {
                self.PCoordx = (hitNode.first?.worldCoordinates.x)!
                self.PCoordy = (hitNode.first?.worldCoordinates.y)!
                self.PCoordz = (hitNode.first?.worldCoordinates.z)!
            }
            
        case .changed:
            let hitNode = sceneView.hitTest(sender.location(in: sceneView), options: nil)
            if let coordx = hitNode.first?.worldCoordinates.x,
                let coordy = hitNode.first?.worldCoordinates.y,
                let coordz = hitNode.first?.worldCoordinates.z {
                let action = SCNAction.moveBy(x: CGFloat(coordx - PCoordx),
                                              y: CGFloat(coordy - PCoordy),
                                              z: CGFloat(coordz - PCoordz),
                                              duration: 0.0)
                if selectedNode?.parent?.name == "rocketship" {
                    self.selectedNode?.parent!.runAction(action)
                } else {
                    self.selectedNode?.runAction(action)
                }
                self.PCoordx = coordx
                self.PCoordy = coordy
                self.PCoordz = coordz
            }
            
            sender.setTranslation(CGPoint.zero, in: self.sceneView)
        case .ended:
            self.PCoordx = 0.0
            self.PCoordy = 0.0
            self.PCoordz = 0.0
        default:
            break
        }
    }
    
    func removeAllObj() {
        sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
            self.objectName.isHidden = true
            if selectedNode == node {
                if node.parent?.name == "rocketship" {
                    node.parent?.removeFromParentNode()
                } else {
                    node.removeFromParentNode()
                }
            }
        }
    }
    
    func update(_ node: inout SCNNode, withGeometry geometry: SCNGeometry, type: SCNPhysicsBodyType) {
        let shape = SCNPhysicsShape(geometry: geometry, options: nil)
        let physicsBody = SCNPhysicsBody(type: type, shape: shape)
        node.physicsBody = physicsBody
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        
        let width = CGFloat(planeAnchor.extent.x)
        let height = CGFloat(planeAnchor.extent.z)
        let plane = SCNPlane(width: width, height: height)
        
        plane.materials.first?.diffuse.contents = UIColor.transparentWhite
        
        var planeNode = SCNNode(geometry: plane)
        
        let x = CGFloat(planeAnchor.center.x)
        let y = CGFloat(planeAnchor.center.y)
        let z = CGFloat(planeAnchor.center.z)
        planeNode.position = SCNVector3(x,y,z)
        planeNode.eulerAngles.x = -.pi / 2
        
        // TODO: Update plane node
        update(&planeNode, withGeometry: plane, type: .static)
        
        node.addChildNode(planeNode)
        
        // TODO: Append plane node to plane nodes array if appropriate
        planeNodes.append(planeNode)
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        guard anchor is ARPlaneAnchor,
            let planeNode = node.childNodes.first
            else { return }
        planeNodes = planeNodes.filter { $0 != planeNode }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as?  ARPlaneAnchor,
            var planeNode = node.childNodes.first,
            let plane = planeNode.geometry as? SCNPlane
            else { return }
        
        let width = CGFloat(planeAnchor.extent.x)
        let height = CGFloat(planeAnchor.extent.z)
        plane.width = width
        plane.height = height
        
        let x = CGFloat(planeAnchor.center.x)
        let y = CGFloat(planeAnchor.center.y)
        let z = CGFloat(planeAnchor.center.z)
        
        planeNode.position = SCNVector3(x, y, z)
        
        update(&planeNode, withGeometry: plane, type: .static)
        
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}

extension UIColor {
    open class var transparentWhite: UIColor {
        return UIColor.white.withAlphaComponent(0.20)
    }
}

extension float4x4 {
    var translation: float3 {
        let translation = self.columns.3
        return float3(translation.x, translation.y, translation.z)
    }
}
