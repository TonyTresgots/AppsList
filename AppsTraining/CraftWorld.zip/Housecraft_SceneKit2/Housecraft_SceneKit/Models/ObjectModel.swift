//
//  ObjectModel.swift
//  Housecraft_SceneKit
//
//  Created by Tony Tresgots on 05/12/2019.
//  Copyright © 2019 Tony Tresgots. All rights reserved.
//

import Foundation
import SceneKit

class ObjectModel {        // si nous voulons simplifier -> funcs for refactoring and reuse / je ne les ai pas utilisées
    
    class func getObjectName(objectName: String) -> SCNNode {
        switch objectName {
        case "pipe":
            return ObjectModel.getPipes()
        case "pyramid":
            return ObjectModel.getPyramid()
        case "quarter":
            return ObjectModel.getQuarter()
        case "submarine":
            return ObjectModel.getSubmarine()
        case "rocketship":
            return ObjectModel.getRocket()
        case "ship":
            return ObjectModel.getShip()
        default:
            return ObjectModel.getSubmarine()
        }
    }
    
    class func getPipes() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/pipe.dae")!    // on recupere la scene entiere pipe.dae
        let node = obj.rootNode.childNode(withName: "pipe", recursively: true)  // on recupere seulement l'objet de la scene pipe.dae / "pipe" étant l'id donné a l'objet
        node?.scale = SCNVector3Make(0.0020, 0.0020, 0.0020)   // modifie taille / diminution taille
        node?.position = SCNVector3Make(-2.3, 0.7, -1)  // modifie position
        return node!
    }
    
    class func getPyramid() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/pyramid.dae")!
        let node = obj.rootNode.childNode(withName: "pyramid", recursively: true)
        node?.scale = SCNVector3Make(0.0058, 0.0058, 0.0058)
        node?.position = SCNVector3Make(-2.3, -0.62, -1)

        return node!
    }
    
    class func getQuarter() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/quarter.dae")!
        let node = obj.rootNode.childNode(withName: "quarter", recursively: true)
        node?.scale = SCNVector3Make(0.0058, 0.0058, 0.0058)
        node?.position = SCNVector3Make(-2.3, -2.4, -1)

        return node!
    }
    
    class func getSubmarine() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/submarine.dae")!
        let node = obj.rootNode.childNode(withName: "submarine", recursively: true)
        node?.scale = SCNVector3Make(0.058, 0.058, 0.058)
        node?.position = SCNVector3Make(-1, 0.7, -2)

        return node!
    }
    
    class func getRocket() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/rocketship.scn")!
        let node = obj.rootNode.childNode(withName: "rocketship", recursively: true)
        
        node?.scale = SCNVector3Make(0.1, 0.1, 0.1)
        node?.position = SCNVector3Make(-1, -0.9, -2)

        return node!
    }
    
    class func getShip() -> SCNNode {
        let obj = SCNScene(named: "art.scnassets/ship.scn")!
        let node = obj.rootNode.childNode(withName: "ship", recursively: true)
        
        node?.scale = SCNVector3Make(0.058, 0.058, 0.058)
        node?.position = SCNVector3Make(-1, -2.4, -2)

        return node!
    }
        
    class func startRotation(node: SCNNode) {
        let rotate = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: CGFloat(0.01 * Double.pi), z: 0, duration: 0.1))   // rotation des items du popover
        node.runAction(rotate)     // rotate item
    }
}

