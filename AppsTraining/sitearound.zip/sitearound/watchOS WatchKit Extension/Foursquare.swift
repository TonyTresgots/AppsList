//
//  location.swift
//  Monuments WatchKit Extension
//
//  Created by Alessandro s. on 14/01/2020.
//  Copyright © 2020 MyTie. All rights reserved.
//

import Foundation
import CoreLocation
import SwiftUI

struct Data: Decodable {
    var response: Response
}

struct Response: Decodable {
    var groups: [Group]
}

struct Group: Decodable {
    var items: [Item]
}

struct Item: Decodable {
    var venue: Venue
}

struct Venue: Decodable {
    var id: String
    var name: String
    var location: Location
    var categories: [Category]
}

struct Location: Decodable {
    var lat: Double
    var lng: Double
}

struct Category: Decodable {
    var icon: Icon
}

struct Icon: Decodable {
    var prefix: String
    var suffix: String
}

struct Row: Identifiable {
    var id: UUID
    var item: Item
}

public class Foursquare: ObservableObject{
    @Published var items = [Row]()
    
    var latitude: Double!
    var longitude: Double!

    
    var client_id = "D1JFGLPGMJFGE415VJTSP2B2SEJL5VT1BJ0O4IQTVNKAWJRJ"
    var client_secret = "4KCDZLNRZG3RCCW3A04RSIWKXFBVSE15G0JYGFIXBJDZ3TXZ"
    
    init(){
        load()
    }
    
    func load() {
        let url = URL(string: "https://api.foursquare.com/v2/venues/explore?client_id=D1JFGLPGMJFGE415VJTSP2B2SEJL5VT1BJ0O4IQTVNKAWJRJ&client_secret=4KCDZLNRZG3RCCW3A04RSIWKXFBVSE15G0JYGFIXBJDZ3TXZ&v=20180323&limit=30&ll=41.89193,12.51133&query=Landmarks")!
    
        URLSession.shared.dataTask(with: url) {(data,response,error) in
            do {
                if let d = data {
                    let decodedLists = try JSONDecoder().decode(Data.self, from: d)
                    DispatchQueue.main.async {
                        for item in decodedLists.response.groups[0].items {
                            self.items.append(Row(id: UUID(), item: item))
                        }
                    }
                }else {
                    print("No Data")
                }
            } catch {
                print ("Error \(error)")
            }
            
        }.resume()
    }
}
