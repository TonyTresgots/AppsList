//
//  location.swift
//  Monuments WatchKit Extension
//
//  Created by Alessandro s. on 14/01/2020.
//  Copyright © 2020 MyTie. All rights reserved.
//

import Foundation
import CoreLocation
import SwiftUI

struct Photos: Decodable {
    var response: ResponsePhotos
}

struct ResponsePhotos: Decodable {
    var photos: PhotosPhotos
}

struct PhotosPhotos: Decodable {
    var items: [ItemPhotos]
}

struct ItemPhotos: Decodable {
    var prefix: String
    var suffix: String
}

public class ImageLoader: ObservableObject{
    @Published var image = Image(systemName: "heart.fill") //cannot be nil, gave it random symbol. Can change it later to what you want
    //please don't abuse the use of my client_id and client_secret ;)
    var client_id = "D1JFGLPGMJFGE415VJTSP2B2SEJL5VT1BJ0O4IQTVNKAWJRJ"
    var client_secret = "4KCDZLNRZG3RCCW3A04RSIWKXFBVSE15G0JYGFIXBJDZ3TXZ"
    //
    
    init(_ prefix: String, _ suffix: String, _ venueID: String) {
        loadIcon(prefix, suffix, venueID)
    }
    
    func downloadImage(_ url: URL){
        URLSession.shared.dataTask(with: url) {(data,response,error) in
            if let imageData = data {
                DispatchQueue.main.async {
                    self.image = Image(uiImage: UIImage(data: imageData)!)
                }
            }else {
                print("No Data")
            }
            
            if let err = error {
                print ("Error \(String(describing: err))")
            }
        }.resume()
    }
    
    func loadIcon(_ prefix: String, _ suffix: String,_ venuID: String) {
        let url = URL(string: "\(prefix)bg_88\(suffix)")!
        
        self.downloadImage(url)
        self.requestPhoto(venueID: venuID)
    }
    
    func requestPhoto(venueID: String){
        let url = URL(string: "https://api.foursquare.com/v2/venues/\(venueID)/photos?client_id=\(client_id)&client_secret=\(client_secret)&v=20180323&limit=1")!
        var photoUrl: URL!
        
        URLSession.shared.dataTask(with: url) {(data,response,error) in
            do {
                if let d = data {
                    let decodedLists = try JSONDecoder().decode(Photos.self, from: d)
                    DispatchQueue.main.async {
                        if(decodedLists.response.photos.items.count > 0){
                            let item = decodedLists.response.photos.items[0]
                            photoUrl = URL(string: "\(item.prefix)80x80\(item.suffix)")
                            self.downloadImage(photoUrl)
                        }
                    }
                }else {
                    print("No Data")
                }
            } catch {
                print ("Error \(error)")
            }
            
        }.resume()
    }
}

struct asyncImage: View {
    @ObservedObject var imageLoader: ImageLoader
    
    var body: some View {
       imageLoader.image
        .resizable()
        .aspectRatio(contentMode: .fit)
    }
}
