//
//  LocationManager.swift
//  watchOS_v0.1 WatchKit Extension
//
//  Created by Gennaro Rivetti on 10/01/2020.
//  Copyright © 2020 Gennaro Rivetti. All rights reserved.
//

import Foundation
import CoreLocation
import Combine
import UserNotifications
import SwiftUI
import MapKit
import UIKit


class LocationManager: NSObject, ObservableObject {
    
    static let shared: LocationManager = LocationManager()
    
    var arrayPlaces: [Row]!
    var foursquare = Foursquare()
    
    override init()
    {
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.allowsBackgroundLocationUpdates = true
        self.locationManager.distanceFilter = 125
        self.locationManager.startUpdatingLocation()
        
    }
    
    @Published var locationStatus: CLAuthorizationStatus? {
        willSet {
            objectWillChange.send()
        }
    }
    
    @Published var lastLocation: CLLocation? {
        willSet {
            objectWillChange.send()
        }
    }
    
    var statusString: String
    {
        guard let status = locationStatus else
        {
            return "unknown"
        }
        switch status
        {
        case .notDetermined: return "notDetermined"
        case .authorizedWhenInUse: return "authorizedWhenInUse"
        case .authorizedAlways: return "authorizedAlways"
        case .restricted: return "restricted"
        case .denied: return "denied"
        default: return "unknown"
        }
    }
    
    let objectWillChange = PassthroughSubject<Void, Never>()
    
    private let locationManager = CLLocationManager()
}

extension LocationManager: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        self.locationStatus = status
        print(#function, statusString)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // REMOVE
        LocationManager.shared.arrayPlaces = [foursquare.items.first!]
        
        guard let location = locations.last else { return }
        self.lastLocation = location
        
        // ALGO FILL ARRAY WITH LOCATIONS INSIDE ZONE
        
        for item in foursquare.items {
            let coordinate = CLLocation(latitude: item.item.venue.location.lat, longitude: item.item.venue.location.lng)
            
            if coordinate.distance(from: self.lastLocation!) < 1000 {
                // DISPLAY NOTIF WITH PLACE
                
                LocationManager.shared.arrayPlaces.append(item)
            }
        }
        
        if !LocationManager.shared.arrayPlaces.isEmpty {
            
            if WKExtension.shared().applicationState == .active {
                let h0 = { print("ok")}

                let action1 = WKAlertAction(title: "Show", style: .default, handler:h0)
                let action3 = WKAlertAction(title: "Cancel", style: .cancel) {}
                
                WKExtension.shared().rootInterfaceController!.presentAlert(withTitle: "Monument found", message: "!", preferredStyle: .actionSheet, actions: [action1,action3])
                
            } else if WKExtension.shared().applicationState == .background {
                // TRIGGER NOTIF
                let content = UNMutableNotificationContent()
                content.title = "Monument found"
                content.subtitle = "!"
                content.sound = UNNotificationSound.default
                
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
                
                // choose a random identifier
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                
                // add our notification request
                UNUserNotificationCenter.current().add(request)
            } else {
                // WHEN APP IS INACTIVE
            }
        }
    }
    
    
}
