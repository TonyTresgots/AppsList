//
//  HostingController.swift
//  watchOS WatchKit Extension
//
//  Created by Gennaro Rivetti on 16/01/2020.
//  Copyright © 2020 Gennaro Rivetti. All rights reserved.
//

import WatchKit
import Foundation
import SwiftUI

class HostingController: WKHostingController<ContentView> {
    override var body: ContentView {
        return ContentView()
    }
}
