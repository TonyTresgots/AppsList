//
//  NotificationView.swift
//  watchOS WatchKit Extension
//
//  Created by Gennaro Rivetti on 16/01/2020.
//  Copyright © 2020 Gennaro Rivetti. All rights reserved.
//

import SwiftUI
import MapKit
import UIKit
import UserNotifications

struct NotificationView: View {
    
    var body: some View {
        VStack {
                                    
//            asyncImage(imageLoader: ImageLoader((LocationManager.shared.arrayPlaces.first?.item.venue.categories[0].icon.prefix)!, (LocationManager.shared.arrayPlaces.first?.item.venue.categories[0].icon.suffix)!, (LocationManager.shared.arrayPlaces.first?.item.venue.id)!))
//                .aspectRatio(contentMode: .fill)
//                .frame(width: WKInterfaceDevice.current().screenBounds.width, height: 100, alignment: .center)
            
            Image("coliseum_image")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: WKInterfaceDevice.current().screenBounds.width, height: 100, alignment: .center)

            
            Text("Coliseum")
                .font(.headline)
                .lineLimit(0)
            
            Text("Coliseum is 300m from you")
                .font(Font.system(size: 10.0))
                .lineLimit(0)
            
            Divider()
            
            // DIFFERENT METHODS TO OPEN MAP APP NOT WORKING
            
            //
            //                            NavigationLink(destination: MapView(coords: CLLocationCoordinate2D(latitude: self.coordinate!.latitude, longitude: self.coordinate!.longitude))){
            //                                HStack{
            //                                    Text("iuii")
            //                                }
            //                            }
            //
            //               MapView(coords: self.coordinate!)
            //
            //
            //
            //             WKEXTENSION METHOD
            //                            let myAddress = "One,Apple+Park+Way,Cupertino,CA,95014,USA"
            //                            if let url = URL(string:"http://maps.apple.com/?address=\(myAddress)") {
            //                                WKExtension.shared().openSystemURL(url)
            //                            }
            //
            //             OPEN URL METHOD
            //
            //                            let latitude: CLLocationDegrees = 39.048855
            //                            let longitude: CLLocationDegrees = -120.981227
            //
            //                            let regionDistance: CLLocationDistance = 1000
            //                            let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
            //                            let regionSpan = MKCoordinateRegion(center: coordinates, latitudinalMeters: regionDistance, longitudinalMeters: regionDistance)
            //
            //                            let options = [MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center), MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)]
            //
            //                            let placemark = MKPlacemark(coordinate: coordinates)
            //                            let mapItem = MKMapItem(placemark: placemark)
            //                            mapItem.name = "IJUHYGVGCFTVB"
            //                            mapItem.openInMaps(launchOptions: options)
            
           // if !LocationManager.shared.arrayPlaces.isEmpty {
                NavigationLink(destination: MapView(coords: CLLocationCoordinate2D(latitude: 40.840679, longitude: 14.296296))) {
                    Button("Show") {
                        
                        print("Show tapped")
                    }
                }
           // }
                        
            Text("Remind me later")
                .font(Font.system(size: 10.0))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            
            Button(action: {
                print("")
                let content = UNMutableNotificationContent()
                content.title = "Monument found"
                content.subtitle = "!"
                content.sound = UNNotificationSound.default
                // show this notification five seconds from now
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 900, repeats: false)
                
                // choose a random identifier
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                // add our notification request
                UNUserNotificationCenter.current().add(request)
            }) {
                HStack {
                    Spacer()
                    Text("15 min")
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            
            Button(action: {
                print("")
                let content = UNMutableNotificationContent()
                content.title = "Monument found"
                content.subtitle = "!"
                content.sound = UNNotificationSound.default
                // show this notification five seconds from now
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 7200, repeats: false)
                
                // choose a random identifier
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                // add our notification request
                UNUserNotificationCenter.current().add(request)
            }) {
                HStack {
                    Spacer()
                    Text("2h")
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            
            Button(action: {
                print("")
                let content = UNMutableNotificationContent()
                content.title = "Monument found"
                content.subtitle = "!"
                content.sound = UNNotificationSound.default
                // show this notification five seconds from now
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 86400, repeats: false)
                
                // choose a random identifier
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                // add our notification request
                UNUserNotificationCenter.current().add(request)
            }) {
                HStack {
                    Spacer()
                    Text("Tomorrow")
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            
        }
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        
        NotificationView()
        
    }
}
