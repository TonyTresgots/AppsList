//
//  MapView.swift
//  watchOS_v0.1 WatchKit Extension
//
//  Created by Gennaro Rivetti on 09/01/2020.
//  Copyright © 2020 Gennaro Rivetti. All rights reserved.
//

import SwiftUI

struct MapView: WKInterfaceObjectRepresentable
{
    
//    @ObservedObject var location = LocationManager()
    var coords: CLLocationCoordinate2D
    
//    var landmark: CLLocationCoordinate2D!
    
    func makeWKInterfaceObject(context: WKInterfaceObjectRepresentableContext<MapView>) -> WKInterfaceMap
    {
    // Return the interface object that the view displays.
    return WKInterfaceMap()
    }
    
    func updateWKInterfaceObject(_ wkInterfaceObject: WKInterfaceMap, context: WKInterfaceObjectRepresentableContext<MapView>)
    {
        let span = MKCoordinateSpan(latitudeDelta: 0.01,
                                    longitudeDelta: 0.01)
        
        
        
        let region = MKCoordinateRegion(center: coords, span: span)
        
        wkInterfaceObject.setUserTrackingMode(.follow, animated: true)
        wkInterfaceObject.addAnnotation(coords, with: .red)
        wkInterfaceObject.setRegion(region)
    }
    

}

//struct MapView_Previews: PreviewProvider
//{
//    static var previews: some View
//    {
//        MapView(coords: CLLocationCoordinate2D(latitude: -40, longitude: 7))
//    }
//}
