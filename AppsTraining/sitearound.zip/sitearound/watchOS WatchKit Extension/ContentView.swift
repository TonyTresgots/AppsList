//
//  ContentView.swift
//  watchOS WatchKit Extension
//
//  Created by Gennaro Rivetti on 16/01/2020.
//  Copyright © 2020 Gennaro Rivetti. All rights reserved.
//

import SwiftUI
import UserNotifications

//MARK: Old code
//var place:[String] = ["Milano","Roma","Firenze","Pozzuoli","Ancona","Bologna","Genova"]
//
//struct ContentView: View {
//    var body: some View
//    {
//        List( 0 ..< 7)
//        { item in
//            NavigationLink(destination: MapView())
//            {
//            HStack
//            {
//                Text(place[item]).font(.system(size: 14)).padding(.horizontal, 0)
//            }
//        }
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}

struct ContentView: View {
    @ObservedObject var fetcher = Foursquare()
    
    func addRow(row: Row?) {
        LocationManager.shared.arrayPlaces.append(row!)
    }
    
    var body: some View {
        VStack {
            
            List(fetcher.items) { row in
                NavigationLink(destination: MapView(coords: CLLocationCoordinate2D(latitude: row.item.venue.location.lat, longitude: row.item.venue.location.lng))) {
                    HStack{
                        Text(row.item.venue.name)
                    }
                }
            }
            
            Button(action: {
                
                let content = UNMutableNotificationContent()
                content.title = "Monument found"
                content.subtitle = "!"
                content.sound = UNNotificationSound.default
                // show this notification five seconds from now
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
                
                // choose a random identifier
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                // add our notification request
                UNUserNotificationCenter.current().add(request)
            }) {
                Text("Test Notif")
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


