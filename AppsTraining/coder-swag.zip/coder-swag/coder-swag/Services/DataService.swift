//
//  DataService.swift
//  coder-swag
//
//  Created by Tony Tresgots on 06/01/2018.
//  Copyright © 2018 Tony Tresgots. All rights reserved.
//

import Foundation

class DataService {
    static let instance = DataService()
    
    private let categories = [
        Category(title: "SHIRTS", imageName: "shirts.png"),
        Category(title: "HOODIES", imageName: "hoodies.png"),
        Category(title: "HATS", imageName: "hats.png"),
        Category(title: "DIGITAL", imageName: "digital.png")
    ]
    
    private let hats = [
        Product(title: "Devslopes Logo Graphic Beanie", price:"$18", imageName: "hat01.png"),
        Product(title: "Devslopes Logo Hat Black", price: "$22", imageName: "hat02.png"),
        Product(title: "Devslopes Logo Hat White", price: "$22", imageName: "hat03.png"),
        Product(title: "Devslopes Logo Snapback", price: "$20", imageName: "hat04.png")
    ]
    
    private let hoodies = [
        Product(title: "Devslopes Logo hoodie Grey", price: "$22", imageName: "hoodie01.png"),
        Product(title: "Devslopes Logo hoodie red", price: "$22", imageName: "hoodie02.png"),
        Product(title: "Devslopes hoodie Grey", price: "$22", imageName: "hoodie03.png"),
        Product(title: "Devslopes hoodie Grey", price: "$22", imageName: "hoodie04.png")
    ]
    
    private let shirts = [
        Product(title: "Devslopes Logo Shirt Black", price: "$18", imageName: "shirt01.png"),
        Product(title: "Devslopes Logo Shirt grey", price: "$18", imageName: "shirt02.png"),
        Product(title: "Devslopes Logo Shirt red", price: "$18", imageName: "shirt03.png"),
        Product(title: "Devslopes Logo Shirt Black", price: "$18", imageName: "shirt04.png"),
        Product(title: "Devslopes Kickflip Shirt Black", price: "$18", imageName: "shirt05.png")
    ]
    
    private let digitalGoods = [Product]()
    
    func getProducts(forCategoryTitle title: String) -> [Product] {
        switch title {
        case "SHIRT":
            return getShirts()
        case "HATS":
            return getHats()
        case "HOODIES":
            return getHoodies()
        case "DIGITAL":
            return getDigitalGoods()
            
        default:
            return getShirts()
        }
    }
    
    
    func getCategories() -> [Category] {
        return categories
    }
    
    
    func getHats() -> [Product] {
        return hats
    }
    
    func getHoodies() -> [Product] {
        return hoodies
    }
    
    func getShirts() -> [Product] {
        return shirts
    }
    
    func getDigitalGoods() -> [Product] {
        return digitalGoods
    }
    
    
    
    
    
    
}
