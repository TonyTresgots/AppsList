//
//  CategoryCell.swift
//  coder-swag
//
//  Created by Tony Tresgots on 06/01/2018.
//  Copyright © 2018 Tony Tresgots. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    
    @IBOutlet weak var categoryImage: UIImageView!
    @IBOutlet weak var categoryTitle: UILabel!
    
    
    func updateViews(category: Category) {
        categoryImage.image = UIImage(named: category.imageName)
        categoryTitle.text = category.title
        
    }

}
